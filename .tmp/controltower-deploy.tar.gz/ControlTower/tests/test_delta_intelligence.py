from __future__ import annotations

import json
import sqlite3
import time

from controltower.config import load_config
from controltower.services.controltower import ControlTowerService
from controltower.services.delta import select_comparison_run_record


def test_delta_computation_tracks_run_to_run_changes(sample_config_path):
    config = load_config(sample_config_path)
    service = ControlTowerService(config)
    first_record = service.export_notes(preview_only=False)

    schedule_summary_path = config.sources.schedulelab.published_root / "runs" / "AURORA_HILLS" / "outputs" / "summary.json"
    dashboard_path = config.sources.schedulelab.published_root / "runs" / "AURORA_HILLS" / "outputs" / "dashboard_feed.json"
    run_manifest_path = config.sources.schedulelab.published_root / "runs" / "AURORA_HILLS" / "outputs" / "run_manifest.json"

    summary = json.loads(schedule_summary_path.read_text(encoding="utf-8"))
    summary["finish_date"] = "2026-08-22"
    summary["total_float_days"] = 8.0
    summary["cycle_count"] = 2
    summary["open_finish_count"] = 9
    schedule_summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    dashboard = json.loads(dashboard_path.read_text(encoding="utf-8"))
    dashboard["project"]["finish_date"] = "2026-08-22"
    dashboard["summary"]["total_float_days"] = 8.0
    dashboard["summary"]["cycle_count"] = 2
    dashboard["summary"]["open_finish_count"] = 9
    dashboard["risk_flags"] = ["open_ends", "negative_float", "critical_path_shift"]
    dashboard_path.write_text(json.dumps(dashboard, indent=2), encoding="utf-8")

    run_manifest = json.loads(run_manifest_path.read_text(encoding="utf-8"))
    run_manifest["project"]["finish_date"] = "2026-08-22"
    run_manifest_path.write_text(json.dumps(run_manifest, indent=2), encoding="utf-8")

    with sqlite3.connect(config.sources.profitintel.database_path) as connection:
        connection.execute(
            """
            UPDATE project_financial_snapshots
            SET forecast_final_cost = 930000,
                projected_profit = 90000,
                margin_percent = 9.0
            WHERE report_snapshot_id = 2
            """
        )
        connection.commit()

    time.sleep(1.1)
    portfolio = service.build_portfolio()
    project = portfolio.project_rankings[0]
    second_record = service.export_notes(preview_only=False)

    assert first_record.run_id != second_record.run_id
    assert project.delta.schedule.finish_date_movement_days == 7
    assert project.delta.schedule.float_direction == "compression"
    assert project.delta.financial.margin_movement == -4.0
    assert "critical_path_shift" in project.delta.risk.new_risks
    assert project.health.required_actions


def test_comparison_baseline_is_contained_when_only_current_run_exists(sample_config_path):
    config = load_config(sample_config_path)
    service = ControlTowerService(config)
    service.export_notes(preview_only=False)

    portfolio = service.build_portfolio()
    comparison_record = select_comparison_run_record(
        config.runtime.state_root,
        [(project.identity, project.schedule, project.financial) for project in portfolio.project_rankings],
    )

    assert comparison_record is None
    assert portfolio.comparison_trust.status == "contained"
    assert portfolio.comparison_trust.delta_ranking_enabled is False
