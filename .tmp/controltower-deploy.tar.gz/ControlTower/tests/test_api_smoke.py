from __future__ import annotations

from fastapi.testclient import TestClient

from controltower.api.app import create_app
from controltower.config import load_config
from controltower.services.controltower import ControlTowerService
from controltower.services.meeting_readiness import verify_meeting_readiness


def test_api_and_pages_render(sample_config_path):
    config = load_config(sample_config_path)
    service = ControlTowerService(config)
    record = service.export_notes(preview_only=False)
    app = create_app(str(sample_config_path))
    client = TestClient(app)

    home = client.get("/")
    assert home.status_code == 200
    assert "Executive operating view" in home.text
    assert 'id="root-primary-answer"' in home.text
    assert 'id="root-answer-delta"' in home.text
    assert 'id="root-answer-action"' in home.text
    assert 'id="root-answer-authority"' in home.text
    assert 'id="root-section-material-changes"' in home.text
    assert "Projects Ranked By Health / Risk" not in home.text
    assert client.get("/projects").status_code == 200
    arena = client.get("/arena?selected=AURORA_HILLS")
    arena_export = client.get("/arena/export?selected=AURORA_HILLS")
    arena_artifact = client.get("/arena/export/artifact.md?selected=AURORA_HILLS")
    default_arena = client.get("/arena")
    default_arena_artifact = client.get("/arena/export/artifact.md")
    assert default_arena.status_code == 200
    assert client.get("/arena/export").status_code == 200
    assert default_arena_artifact.status_code == 200
    assert 'id="arena-project-answers"' in default_arena.text
    assert "Showing current Control Tower lead: AURORA_HILLS" in default_arena.text
    assert "Showing current Control Tower lead: AURORA_HILLS" in default_arena_artifact.text
    assert arena.status_code == 200
    assert arena_export.status_code == 200
    assert arena_artifact.status_code == 200
    assert 'id="arena-project-answers"' in arena.text
    assert 'id="arena-supporting-preview"' in arena.text
    assert "Projected finish" in arena.text
    assert "Download Authoritative Markdown" in arena.text
    assert "Print / PDF view is presentation-only" in arena_export.text
    assert "## Scope / Timestamp" in arena_artifact.text
    assert "## Project Finish Answers" in arena_artifact.text
    assert "- Project: AURORA_HILLS" in arena_artifact.text
    assert "- Finish:" in arena_artifact.text
    assert "- Delta:" in arena_artifact.text
    assert "- Timing:" in arena_artifact.text
    assert "## Supporting Detail" in arena_artifact.text
    assert "Agenda order: AURORA_HILLS" in arena_artifact.text
    assert "Trust-bounded ranking" in arena_artifact.text
    meeting = verify_meeting_readiness(config, ["AURORA_HILLS"])
    assert meeting["status"] == "pass"
    assert meeting["checks"]["root_project_answer_first_screen"] is True
    assert meeting["checks"]["root_finish_visible_without_expansion"] is True
    assert meeting["checks"]["arena_project_answers_lead_visible_surface"] is True
    assert meeting["checks"]["artifact_preserves_finish_contract"] is True
    assert client.get("/runs").status_code == 200
    assert client.get("/diagnostics").status_code == 200
    assert client.get(f"/runs/{record.run_id}").status_code == 200
    assert client.get("/projects/AURORA_HILLS/compare").status_code == 200
    assert client.get("/api/portfolio").status_code == 200
    assert client.get("/api/diagnostics").status_code == 200
    payload = client.get("/api/projects/AURORA_HILLS").json()
    assert payload["canonical_project_id"] == "AURORA_HILLS"
    assert payload["domain"] == "professional"
    portfolio_payload = client.get("/api/portfolio").json()
    assert portfolio_payload["comparison_trust"]["status"] == "contained"
    assert portfolio_payload["comparison_trust"]["ranking_authority"] == "trust_bounded"
    assert portfolio_payload["domain_coverage"][1]["available"] is False
    assert "projected finish not available" not in home.text.lower()
    assert "no finish-date delta was emitted" not in home.text.lower()
