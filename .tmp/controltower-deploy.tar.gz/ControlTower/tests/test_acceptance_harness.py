from __future__ import annotations

from controltower.acceptance.harness import run_acceptance
from controltower.config import load_config


def test_acceptance_harness_passes(sample_config_path):
    config = load_config(sample_config_path)
    result = run_acceptance(config)

    assert result["status"] == "pass"
    assert result["note_count"] >= 3
    assert result["written_note_count"] >= 3
    assert result["route_checks"]["arena_artifact_route"] == 200
    assert result["coherence_checks"]["trust_state_visible_on_root"] is True
    assert result["coherence_checks"]["trust_state_visible_on_arena"] is True
    assert result["coherence_checks"]["no_distinct_prior_is_contained"] is True
