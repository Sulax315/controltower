from __future__ import annotations

from controltower.config import load_config
from controltower.services.meeting_readiness import verify_meeting_readiness


def test_meeting_readiness_contract_passes(sample_config_path):
    config = load_config(sample_config_path)

    result = verify_meeting_readiness(config, ["AURORA_HILLS"])

    assert result["status"] == "pass"
    assert result["checks"]["root_project_answer_first_screen"] is True
    assert result["checks"]["root_finish_visible_without_expansion"] is True
    assert result["checks"]["root_delta_visible_without_expansion"] is True
    assert result["checks"]["root_issue_and_action_visible_without_expansion"] is True
    assert result["checks"]["root_trust_visible_without_expansion"] is True
    assert result["checks"]["root_top_surface_is_not_category_first"] is True
    assert result["checks"]["root_sections_obey_project_decision_contract"] is True
    assert result["checks"]["root_finish_reason_is_deterministic"] is True
    assert result["checks"]["arena_project_answers_lead_visible_surface"] is True
    assert result["checks"]["arena_finish_visible_without_expansion"] is True
    assert result["checks"]["arena_delta_visible_without_expansion"] is True
    assert result["checks"]["arena_issue_and_action_visible_without_expansion"] is True
    assert result["checks"]["arena_trust_visible_without_expansion"] is True
    assert result["checks"]["arena_top_surface_is_not_category_first"] is True
    assert result["checks"]["arena_sections_obey_project_decision_contract"] is True
    assert result["checks"]["arena_finish_reason_is_deterministic"] is True
    assert result["checks"]["artifact_starts_with_project_finish_answers"] is True
    assert result["checks"]["artifact_preserves_finish_contract"] is True
    assert result["checks"]["cross_surface_finish_semantics_align"] is True
    assert result["checks"]["stale_vague_finish_language_absent"] is True
