from __future__ import annotations

import html
from pathlib import Path
import re
from typing import Any

from fastapi.testclient import TestClient

from controltower.config import ControlTowerConfig, load_config
from controltower.services.controltower import ControlTowerService


ARTIFACT_HEADINGS = (
    "## Scope / Timestamp",
    "## Project Finish Answers",
    "## Trust Posture / Baseline",
    "## Supporting Detail",
)
STALE_VAGUE_FINISH_LANGUAGE = (
    "projected finish not available",
    "no finish-date delta was emitted",
)
CATEGORY_FIRST_LABELS = (
    "Material Change",
    "High Risk",
    "Overall Posture",
)


def verify_meeting_readiness(config: ControlTowerConfig, selected_codes: list[str] | None = None) -> dict[str, Any]:
    from controltower.api.app import create_app_from_config

    service = ControlTowerService(config)
    app = create_app_from_config(config)
    client = TestClient(app)

    portfolio = service.build_portfolio()
    selected = _selected_codes(portfolio.project_rankings, selected_codes)
    tower = service.build_control_tower(selected)
    arena = service.build_arena(selected)

    root_response = client.get("/")
    arena_response = client.get(_path("/arena", selected))
    artifact_response = client.get(_path("/arena/export/artifact.md", selected))

    root_html = root_response.text
    arena_html = arena_response.text
    artifact_text = artifact_response.text
    root_visible_prefix = _surface_visible_prefix(root_html, 'id="root-executive-prelude"')
    arena_visible_prefix = _surface_visible_prefix(arena_html, 'id="arena-executive-prelude"')
    root_visible_text = html.unescape(root_visible_prefix)
    arena_visible_text = html.unescape(arena_visible_prefix)
    root_focus_prefix = _prefix_until(root_visible_text, 'id="root-supporting-preview"')
    arena_focus_prefix = _prefix_until(arena_visible_text, 'id="arena-supporting-preview"')
    root_visible_word_count = _word_count(root_visible_prefix)
    arena_visible_word_count = _word_count(arena_visible_prefix)
    root_answer = tower.primary_project_answer
    arena_answers = arena.project_answers
    arena_primary = arena_answers[0] if arena_answers else None

    checks = {
        "root_project_answer_first_screen": root_answer is not None
        and _ordered(
            root_html,
            (
                'id="root-executive-prelude"',
                'id="root-primary-answer"',
                'id="root-answer-delta"',
                'id="root-answer-issue"',
                'id="root-answer-action"',
                'id="root-answer-authority"',
                'id="root-trust-posture"',
                'id="root-supporting-preview"',
            ),
        )
        and root_visible_word_count <= 420,
        "root_finish_visible_without_expansion": root_answer is not None
        and "Projected finish" in root_visible_text
        and root_answer.projected_finish_label in root_visible_text,
        "root_delta_visible_without_expansion": root_answer is not None
        and _answer_line_visible(root_visible_text, root_answer.movement_label, root_answer.movement_reason),
        "root_issue_and_action_visible_without_expansion": root_answer is not None
        and root_answer.primary_issue in root_visible_text
        and root_answer.required_action in root_visible_text,
        "root_trust_visible_without_expansion": root_answer is not None
        and root_answer.trust_label in root_visible_text
        and tower.comparison_trust.baseline_label in root_visible_text,
        "root_top_surface_is_not_category_first": _contains_none(root_focus_prefix, CATEGORY_FIRST_LABELS),
        "root_finish_reason_is_deterministic": root_answer is not None and _answer_reason_contract(root_answer),
        "root_sections_obey_project_decision_contract": _sections_obey_project_decision_contract(
            (
                tower.material_changes_section,
                tower.required_actions_section,
                tower.rising_risks_section,
                tower.watch_items_section,
            )
        ),
        "arena_project_answers_lead_visible_surface": arena_primary is not None
        and _ordered(
            arena_html,
            (
                'id="arena-executive-prelude"',
                'id="arena-project-answers"',
                'id="arena-supporting-preview"',
                'id="arena-executive-scan"',
            ),
        )
        and arena_visible_word_count <= 420,
        "arena_finish_visible_without_expansion": arena_primary is not None
        and arena_primary.projected_finish_label in arena_visible_text
        and "Projected finish" in arena_visible_text,
        "arena_delta_visible_without_expansion": arena_primary is not None
        and _answer_line_visible(arena_visible_text, arena_primary.movement_label, arena_primary.movement_reason),
        "arena_issue_and_action_visible_without_expansion": arena_primary is not None
        and arena_primary.primary_issue in arena_visible_text
        and arena_primary.required_action in arena_visible_text,
        "arena_trust_visible_without_expansion": arena_primary is not None
        and arena_primary.trust_label in arena_visible_text
        and arena.comparison_trust.baseline_label in arena_visible_text,
        "arena_top_surface_is_not_category_first": _contains_none(arena_focus_prefix, CATEGORY_FIRST_LABELS),
        "arena_finish_reason_is_deterministic": all(_answer_reason_contract(answer) for answer in arena_answers),
        "arena_sections_obey_project_decision_contract": _sections_obey_project_decision_contract(
            (
                arena.material_changes_section,
                arena.why_it_matters_section,
                arena.required_actions_section,
                arena.rising_risks_section,
            )
        ),
        "artifact_starts_with_project_finish_answers": _ordered(artifact_text, ARTIFACT_HEADINGS),
        "artifact_preserves_finish_contract": _artifact_preserves_finish_contract(arena, artifact_text),
        "cross_surface_finish_semantics_align": _cross_surface_finish_semantics_align(root_answer, arena_primary, root_html, arena_html, artifact_text),
        "stale_vague_finish_language_absent": _contains_none((root_html + "\n" + arena_html + "\n" + artifact_text).lower(), STALE_VAGUE_FINISH_LANGUAGE),
    }

    return {
        "status": "pass"
        if all(checks.values()) and root_response.status_code == 200 and arena_response.status_code == 200 and artifact_response.status_code == 200
        else "fail",
        "selected_codes": selected,
        "root_status_code": root_response.status_code,
        "arena_status_code": arena_response.status_code,
        "artifact_status_code": artifact_response.status_code,
        "checks": checks,
        "density": {
            "root_visible_word_count": root_visible_word_count,
            "arena_visible_word_count": arena_visible_word_count,
        },
        "root_visible_excerpt": root_visible_prefix.splitlines()[:16],
        "arena_visible_excerpt": arena_visible_prefix.splitlines()[:16],
        "artifact_excerpt": artifact_text.splitlines()[:24],
    }


def verify_meeting_readiness_from_path(config_path: Path | str) -> dict[str, Any]:
    return verify_meeting_readiness(load_config(Path(config_path)))


def _selected_codes(projects, selected_codes: list[str] | None) -> list[str]:
    if selected_codes:
        return list(selected_codes)
    return [project.canonical_project_code for project in projects[: min(2, len(projects))]]


def _ordered(text: str, tokens: tuple[str, ...]) -> bool:
    cursor = -1
    for token in tokens:
        position = text.find(token)
        if position <= cursor:
            return False
        cursor = position
    return True


def _visible_prefix(text: str) -> str:
    details_index = text.find("<details")
    return text if details_index < 0 else text[:details_index]


def _surface_visible_prefix(text: str, anchor: str) -> str:
    start = text.find(anchor)
    if start < 0:
        return _visible_prefix(text)
    return _visible_prefix(text[start:])


def _prefix_until(text: str, token: str) -> str:
    position = text.find(token)
    return text if position < 0 else text[:position]


def _path(base: str, selected_codes: list[str]) -> str:
    if not selected_codes:
        return base
    return base + "?" + "&".join(f"selected={code}" for code in selected_codes)


def _word_count(text: str) -> int:
    cleaned = re.sub(r"<[^>]+>", " ", text)
    tokens = [token for token in cleaned.split() if token.strip()]
    return len(tokens)


def _contains_none(text: str, tokens) -> bool:
    lowered = text.lower()
    return all(str(token).lower() not in lowered for token in tokens)


def _answer_line_visible(prefix: str, label: str, reason: str | None) -> bool:
    if label in prefix:
        return True
    if reason and reason in prefix:
        return True
    return False


def _answer_reason_contract(answer) -> bool:
    if answer.projected_finish_date is None and not answer.projected_finish_reason:
        return False
    if answer.movement_days is None and not answer.movement_reason:
        return False
    return True


def _sections_obey_project_decision_contract(sections) -> bool:
    for section in sections:
        for item in section.items:
            if not (
                item.who.strip()
                and item.finish.strip()
                and item.delta.strip()
                and item.what.strip()
                and item.why.strip()
                and item.action.strip()
                and item.cause.strip()
                and item.impact.strip()
                and item.timing.strip()
            ):
                return False
            if "projected finish" not in item.finish.lower():
                return False
            if "movement vs prior trusted run" not in item.delta.lower():
                return False
            if "unavailable" in item.finish.lower() and "reason:" not in item.finish.lower():
                return False
            if "unavailable" in item.delta.lower() and "reason:" not in item.delta.lower():
                return False
    return True


def _artifact_preserves_finish_contract(arena, artifact_text: str) -> bool:
    if arena.project_answers:
        for answer in arena.project_answers:
            if answer.project_name not in artifact_text:
                return False
            finish_line = (
                f"Projected finish: {answer.projected_finish_label}"
                if answer.projected_finish_date
                else f"Projected finish unavailable. Reason: {answer.projected_finish_reason}"
            )
            delta_line = (
                f"Movement vs prior trusted run: {answer.movement_label}"
                if answer.movement_days is not None
                else f"Movement vs prior trusted run unavailable. Reason: {answer.movement_reason}"
            )
            if finish_line not in artifact_text or delta_line not in artifact_text:
                return False
            if answer.required_action not in artifact_text:
                return False
    return "- Finish:" in artifact_text and "- Delta:" in artifact_text and "- Action:" in artifact_text


def _cross_surface_finish_semantics_align(root_answer, arena_primary, root_html: str, arena_html: str, artifact_text: str) -> bool:
    if root_answer is None:
        return False
    if root_answer.projected_finish_label not in root_html:
        return False
    if root_answer.movement_label not in root_html and not root_answer.movement_reason:
        return False
    if arena_primary is not None:
        if arena_primary.projected_finish_label not in arena_html:
            return False
        if arena_primary.required_action not in arena_html:
            return False
    finish_line = (
        f"Projected finish: {root_answer.projected_finish_label}"
        if root_answer.projected_finish_date
        else f"Projected finish unavailable. Reason: {root_answer.projected_finish_reason}"
    )
    return finish_line in artifact_text
