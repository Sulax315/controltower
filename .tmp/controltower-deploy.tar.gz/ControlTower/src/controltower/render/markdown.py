from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path
from typing import Any

import yaml
from jinja2 import Environment, FileSystemLoader, select_autoescape

from controltower.config import ObsidianConfig
from controltower.domain.models import ArenaView, GeneratedNote, PortfolioSummary, ProjectSnapshot


REQUIRED_MARKDOWN_TEMPLATES = (
    "arena_export_artifact.md.j2",
    "portfolio_weekly_summary.md.j2",
    "project_dossier.md.j2",
    "project_weekly_brief.md.j2",
)


def validate_markdown_templates() -> None:
    template_root = Path(__file__).resolve().parent / "templates"
    missing = [template_root / template_name for template_name in REQUIRED_MARKDOWN_TEMPLATES if not (template_root / template_name).exists()]
    if missing:
        missing_list = ", ".join(str(path) for path in missing)
        raise FileNotFoundError(f"Control Tower markdown templates are missing: {missing_list}")


def _template_env() -> Environment:
    template_root = Path(__file__).resolve().parent / "templates"
    validate_markdown_templates()
    return Environment(
        loader=FileSystemLoader(str(template_root)),
        autoescape=select_autoescape(enabled_extensions=("html",)),
        trim_blocks=False,
        lstrip_blocks=False,
    )


def render_project_dossier(project: ProjectSnapshot, obsidian: ObsidianConfig, generated_at: str) -> GeneratedNote:
    title = f"{project.project_name} - {obsidian.canonical_dossier_suffix}"
    run_date = generated_at[:10]
    frontmatter = {
        "title": title,
        "type": "project_dossier",
        "project_code": project.canonical_project_code,
        "project_id": project.canonical_project_id,
        "project_name": project.project_name,
        "health_tier": project.health.tier,
        "health_score": project.health.score,
        "risk_level": project.health.risk_level,
        "generated_at": generated_at,
        "run_date": run_date,
        "tags": ["controltower", "project-dossier", project.canonical_project_code.lower()],
    }
    body = _document(
        template_name="project_dossier.md.j2",
        frontmatter=frontmatter,
        context={
            "project": project,
            "portfolio_note": obsidian.rolling_portfolio_note_name,
            "project_brief_name": obsidian.rolling_project_brief_name,
            "prior_week_link": _prior_week_link(
                generated_at=generated_at,
                project_code=project.canonical_project_code,
                title=title,
            ),
        },
    )
    return GeneratedNote(
        note_kind="project_dossier",
        canonical_project_code=project.canonical_project_code,
        title=title,
        frontmatter=frontmatter,
        body=body,
        output_path=Path(obsidian.projects_folder) / project.project_name / f"{title}.md",
        wikilinks=[obsidian.rolling_portfolio_note_name, obsidian.rolling_project_brief_name],
    )


def render_project_weekly_brief(project: ProjectSnapshot, obsidian: ObsidianConfig, generated_at: str) -> GeneratedNote:
    title = f"{project.project_name} - {obsidian.rolling_project_brief_name}"
    run_date = generated_at[:10]
    frontmatter = {
        "title": title,
        "type": "project_weekly_brief",
        "project_code": project.canonical_project_code,
        "project_id": project.canonical_project_id,
        "project_name": project.project_name,
        "generated_at": generated_at,
        "run_date": run_date,
        "health_score": project.health.health_score,
        "risk_level": project.health.risk_level,
        "tags": ["controltower", "weekly-brief", project.canonical_project_code.lower()],
    }
    body = _document(
        template_name="project_weekly_brief.md.j2",
        frontmatter=frontmatter,
        context={
            "project": project,
            "portfolio_note": obsidian.rolling_portfolio_note_name,
            "prior_week_link": _prior_week_link(
                generated_at=generated_at,
                project_code=project.canonical_project_code,
                title=title,
            ),
        },
    )
    return GeneratedNote(
        note_kind="project_weekly_brief",
        canonical_project_code=project.canonical_project_code,
        title=title,
        frontmatter=frontmatter,
        body=body,
        output_path=Path(obsidian.projects_folder) / project.project_name / f"{obsidian.rolling_project_brief_name}.md",
        wikilinks=[obsidian.rolling_portfolio_note_name],
    )


def render_portfolio_summary(summary: PortfolioSummary, obsidian: ObsidianConfig) -> GeneratedNote:
    title = obsidian.rolling_portfolio_note_name
    run_date = summary.generated_at[:10]
    frontmatter = {
        "title": title,
        "type": "portfolio_weekly_summary",
        "generated_at": summary.generated_at,
        "run_date": run_date,
        "project_count": summary.project_count,
        "active_project_count": summary.active_project_count,
        "tags": ["controltower", "portfolio-summary"],
    }
    body = _document(
        template_name="portfolio_weekly_summary.md.j2",
        frontmatter=frontmatter,
        context={"summary": summary},
    )
    return GeneratedNote(
        note_kind="portfolio_weekly_summary",
        title=title,
        frontmatter=frontmatter,
        body=body,
        output_path=Path(obsidian.exports_folder) / f"{title}.md",
        wikilinks=[project.project_name for project in summary.project_rankings[:10]],
    )


def render_arena_export_artifact(arena: ArenaView) -> str:
    frontmatter = {
        "title": arena.artifact_title,
        "type": "arena_export_artifact",
        "generated_at": arena.generated_at,
        "selection_count": len(arena.selected_arena_codes),
        "selected_codes": list(arena.selected_arena_codes),
        "comparison_status": arena.comparison_trust.status,
        "comparison_run_id": arena.comparison_trust.comparison_run_id,
        "ranking_authority": arena.comparison_trust.ranking_authority,
        "ranking_label": arena.comparison_trust.ranking_label,
        "baseline_label": arena.comparison_trust.baseline_label,
    }
    return _document(
        template_name="arena_export_artifact.md.j2",
        frontmatter=frontmatter,
        context={"arena": arena},
    )


def _document(template_name: str, frontmatter: dict[str, Any], context: dict[str, Any]) -> str:
    template = _template_env().get_template(template_name)
    body = template.render(**context).strip() + "\n"
    yaml_block = yaml.safe_dump(frontmatter, sort_keys=False, allow_unicode=False).strip()
    return f"---\n{yaml_block}\n---\n\n{body}"


def _prior_week_link(*, generated_at: str, project_code: str, title: str) -> str:
    current_date = date.fromisoformat(generated_at[:10])
    prior_date = (current_date - timedelta(days=7)).isoformat()
    return f"Weekly/{prior_date}/Projects/{project_code}/{title}"
