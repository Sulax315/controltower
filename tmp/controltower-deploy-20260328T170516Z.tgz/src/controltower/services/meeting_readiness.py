from __future__ import annotations

from pathlib import Path
import re
from typing import Any

from fastapi.testclient import TestClient

from controltower.config import ControlTowerConfig, load_config
from controltower.services.controltower import ControlTowerService


ROOT_SCAN_ORDER = (
    'id="root-scan-posture"',
    'id="root-scan-change"',
    'id="root-scan-action"',
    'id="root-scan-risk"',
)
ARENA_SCAN_ORDER = (
    'id="arena-scan-headline"',
    'id="arena-scan-change"',
    'id="arena-scan-impact"',
    'id="arena-scan-decision"',
)
ARTIFACT_HEADINGS = (
    "## Scope / Timestamp",
    "## Trust Posture / Baseline",
    "## Headline Posture",
    "## Material Changes",
    "## Required Actions / Decisions",
    "## Rising Risks / Watch Items",
    "## Supporting Project Detail",
)
ARTIFACT_SUMMARY_HEADINGS = (
    "## Material Changes",
    "## Required Actions / Decisions",
    "## Rising Risks / Watch Items",
)


def verify_meeting_readiness(config: ControlTowerConfig, selected_codes: list[str] | None = None) -> dict[str, Any]:
    from controltower.api.app import create_app_from_config

    service = ControlTowerService(config)
    app = create_app_from_config(config)
    client = TestClient(app)

    portfolio = service.build_portfolio()
    selected = _selected_codes(portfolio.project_rankings, selected_codes)
    tower = service.build_control_tower(selected)
    arena = service.build_arena(selected)

    root_response = client.get("/")
    arena_response = client.get(_path("/arena", selected))
    artifact_response = client.get(_path("/arena/export/artifact.md", selected))

    root_html = root_response.text
    arena_html = arena_response.text
    artifact_text = artifact_response.text
    root_visible_prefix = _surface_visible_prefix(root_html, 'id="root-executive-prelude"')
    arena_visible_prefix = _surface_visible_prefix(arena_html, 'id="arena-executive-prelude"')
    root_visible_word_count = _word_count(root_visible_prefix)
    arena_visible_word_count = _word_count(arena_visible_prefix)

    checks = {
        "root_leads_with_posture_change_action_risk": _ordered(root_html, ROOT_SCAN_ORDER),
        "root_first_screen_preserves_executive_hierarchy": _ordered(
            root_html,
            (
                'id="root-executive-prelude"',
                'id="root-executive-scan"',
                'id="root-supporting-preview"',
                'id="root-section-material-changes"',
            ),
        )
        and root_visible_word_count <= 380,
        "root_major_sections_are_progressively_disclosed": root_html.count('data-progressive-section="root"') >= 6,
        "root_trust_visible_without_expansion": (
            tower.comparison_trust.ranking_label in root_visible_prefix
            and tower.comparison_trust.baseline_label in root_visible_prefix
        ),
        "root_required_actions_visible_without_expansion": (
            not tower.required_actions_section.items
            or tower.required_actions_section.items[0].action in root_visible_prefix
        ),
        "root_schedule_signal_visible_without_expansion": (
            not tower.material_changes_section.items
            or tower.material_changes_section.items[0].impact in root_visible_prefix
        ),
        "root_sections_obey_project_decision_contract": _sections_obey_project_decision_contract(
            (
                tower.material_changes_section,
                tower.required_actions_section,
                tower.rising_risks_section,
                tower.watch_items_section,
            )
        ),
        "root_scan_cards_stay_brief": _scan_cards_are_brief(tower.executive_scan),
        "root_collapsible_sections_lead_with_project_codes": _sections_lead_with_project_codes(
            (
                tower.material_changes_section,
                tower.required_actions_section,
                tower.rising_risks_section,
                tower.watch_items_section,
            )
        ),
        "arena_preserves_executive_narrative_order": _ordered(arena_html, ARENA_SCAN_ORDER)
        and _ordered(
            arena_html,
            (
                'id="arena-section-material-changes"',
                'id="arena-section-why-it-matters"',
                'id="arena-section-required-actions"',
                'id="arena-section-rising-risks"',
            ),
        ),
        "arena_major_sections_are_progressively_disclosed": arena_html.count('data-progressive-section="arena"') >= 4
        and arena_html.count('data-progressive-section="arena-agenda"') >= max(1, len(arena.items)),
        "arena_trust_and_decision_visible_without_expansion": (
            arena.comparison_trust.ranking_label in arena_visible_prefix
            and arena.comparison_trust.baseline_label in arena_visible_prefix
            and (
                not arena.required_actions_section.items
                or arena.required_actions_section.items[0].action in arena_visible_prefix
            )
        ),
        "arena_schedule_signal_visible_without_expansion": (
            not arena.material_changes_section.items
            or arena.material_changes_section.items[0].impact in arena_visible_prefix
        ),
        "arena_sections_obey_project_decision_contract": _sections_obey_project_decision_contract(
            (
                arena.material_changes_section,
                arena.why_it_matters_section,
                arena.required_actions_section,
                arena.rising_risks_section,
            )
        ),
        "arena_collapsible_sections_lead_with_project_codes": _sections_lead_with_project_codes(
            (
                arena.material_changes_section,
                arena.why_it_matters_section,
                arena.required_actions_section,
                arena.rising_risks_section,
            )
        ),
        "arena_is_more_presentation_oriented_than_root": arena_visible_word_count < root_visible_word_count
        and _scan_cards_are_brief(arena.executive_scan),
        "artifact_preserves_executive_packet_discipline": _ordered(artifact_text, ARTIFACT_HEADINGS)
        and _artifact_headings_have_summaries(artifact_text, ARTIFACT_SUMMARY_HEADINGS)
        and "## Export Context" not in artifact_text
        and "## Ordered Agenda" not in artifact_text
        and _artifact_body_remains_bulleted(artifact_text),
        "artifact_preserves_narrative_contract": (
            arena.selection_summary in artifact_text
            and arena.comparison_trust.ranking_label in artifact_text
            and arena.headline_posture in artifact_text
            and "- Cause:" in artifact_text
            and "- Impact:" in artifact_text
            and "- Action:" in artifact_text
            and "- Timing:" in artifact_text
        ),
    }

    return {
        "status": "pass" if all(checks.values()) and root_response.status_code == 200 and arena_response.status_code == 200 and artifact_response.status_code == 200 else "fail",
        "selected_codes": selected,
        "root_status_code": root_response.status_code,
        "arena_status_code": arena_response.status_code,
        "artifact_status_code": artifact_response.status_code,
        "checks": checks,
        "density": {
            "root_visible_word_count": root_visible_word_count,
            "arena_visible_word_count": arena_visible_word_count,
        },
        "root_visible_excerpt": root_visible_prefix.splitlines()[:16],
        "arena_visible_excerpt": arena_visible_prefix.splitlines()[:16],
        "artifact_excerpt": artifact_text.splitlines()[:24],
    }


def verify_meeting_readiness_from_path(config_path: Path | str) -> dict[str, Any]:
    return verify_meeting_readiness(load_config(Path(config_path)))


def _selected_codes(projects, selected_codes: list[str] | None) -> list[str]:
    if selected_codes:
        return list(selected_codes)
    return [project.canonical_project_code for project in projects[: min(2, len(projects))]]


def _ordered(text: str, tokens: tuple[str, ...]) -> bool:
    cursor = -1
    for token in tokens:
        position = text.find(token)
        if position <= cursor:
            return False
        cursor = position
    return True


def _visible_prefix(text: str) -> str:
    details_index = text.find("<details")
    return text if details_index < 0 else text[:details_index]


def _surface_visible_prefix(text: str, anchor: str) -> str:
    start = text.find(anchor)
    if start < 0:
        return _visible_prefix(text)
    return _visible_prefix(text[start:])


def _path(base: str, selected_codes: list[str]) -> str:
    if not selected_codes:
        return base
    return base + "?" + "&".join(f"selected={code}" for code in selected_codes)


def _word_count(text: str) -> int:
    cleaned = re.sub(r"<[^>]+>", " ", text)
    tokens = [token for token in cleaned.split() if token.strip()]
    return len(tokens)


def _scan_cards_are_brief(cards) -> bool:
    return all(_word_count(card.summary) <= 20 and _word_count(card.detail) <= 20 for card in cards)


def _sections_lead_with_project_codes(sections) -> bool:
    return all(
        (not section.items and section.summary.strip())
        or (
            section.lead_project_code is not None
            and section.summary.startswith(f"{section.lead_project_code}:")
            and _word_count(section.summary) <= 22
        )
        for section in sections
    )


def _sections_obey_project_decision_contract(sections) -> bool:
    for section in sections:
        for item in section.items:
            if not (
                item.who.strip()
                and item.what.strip()
                and item.why.strip()
                and item.action.strip()
                and item.cause.strip()
                and item.impact.strip()
                and item.timing.strip()
            ):
                return False
            if "projected finish" not in item.impact.lower() and "delta versus the prior run is unavailable" not in item.impact.lower():
                return False
    return True


def _artifact_headings_have_summaries(text: str, headings: tuple[str, ...]) -> bool:
    for heading in headings:
        position = text.find(heading)
        if position < 0:
            return False
        if text.find("Summary:", position, position + 220) < 0:
            return False
    return True


def _artifact_body_remains_bulleted(text: str) -> bool:
    body = text
    if text.startswith("---\n"):
        parts = text.split("---\n", 2)
        body = parts[2] if len(parts) == 3 else text
    body_lines = [line.strip() for line in body.splitlines() if line.strip()]
    plain_lines = [
        line
        for line in body_lines
        if not (
            line.startswith("#")
            or line.startswith("- ")
            or line.startswith("Summary:")
            or line.startswith("Why it matters:")
            or line.startswith("Why now:")
            or line.startswith("Decision needed:")
        )
    ]
    return len(plain_lines) <= 1
