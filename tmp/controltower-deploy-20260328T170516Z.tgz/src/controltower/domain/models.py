from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field


HealthTier = Literal["healthy", "watch", "at_risk", "critical"]
RiskLevel = Literal["LOW", "MEDIUM", "HIGH"]
MatchMethod = Literal["manual_override", "fuzzy_match", "raw_match"]
NoteKind = Literal["project_dossier", "project_weekly_brief", "portfolio_weekly_summary"]
SurfaceDomain = Literal["professional", "personal"]
ComparisonTrustStatus = Literal["trusted", "contained", "unavailable"]
ComparisonAuthority = Literal["authoritative", "trust_bounded", "unavailable"]


class SourceArtifactRef(BaseModel):
    source_system: Literal["schedulelab", "profitintel", "controltower"]
    artifact_type: str
    path: str
    relative_path: str | None = None
    run_timestamp: str | None = None
    status: Literal["resolved", "missing", "derived"] = "resolved"
    notes: str | None = None


class TrustIndicator(BaseModel):
    status: Literal["high", "partial", "low", "missing"]
    rationale: list[str] = Field(default_factory=list)
    missing_data_flags: list[str] = Field(default_factory=list)


class ComparisonTrust(BaseModel):
    status: ComparisonTrustStatus
    label: str
    detail: str
    comparison_run_id: str | None = None
    delta_ranking_enabled: bool = False
    reason_code: str = "no_prior_run"
    ranking_authority: ComparisonAuthority = "unavailable"
    ranking_label: str = "Change-sensitive ranking unavailable"
    ranking_detail: str = "A trusted prior comparison run is not available, so delta-driven ranking is not authoritative."
    baseline_label: str = "No comparison baseline"
    baseline_detail: str = "No trusted prior comparison baseline is available for this surface."


class DomainCoverage(BaseModel):
    domain: SurfaceDomain
    label: str
    available: bool
    item_count: int
    detail: str


class ProjectIdentity(BaseModel):
    canonical_project_id: str
    canonical_project_code: str
    project_name: str
    source_keys: list[str] = Field(default_factory=list)
    aliases: list[str] = Field(default_factory=list)
    match_method: MatchMethod = "raw_match"
    matched_on: str | None = None


class ScheduleDriver(BaseModel):
    label: str
    score: float | None = None
    rationale: str | None = None


class IssueDriver(BaseModel):
    source: Literal["schedule", "financial", "cross_source"]
    severity: Literal["high", "medium", "low"]
    label: str
    detail: str


class RecommendedAction(BaseModel):
    priority: Literal["high", "medium", "low"]
    owner_hint: str
    action: str


class ScheduleSummary(BaseModel):
    project_code: str
    project_name: str
    run_timestamp: str | None = None
    schedule_date: str | None = None
    finish_date: str | None = None
    health_score: float | None = None
    issues_total: int | None = None
    activity_count: int | None = None
    relationship_count: int | None = None
    negative_float_count: int | None = None
    open_start_count: int | None = None
    open_finish_count: int | None = None
    cycle_count: int | None = None
    top_driver_count: int | None = None
    risk_path_count: int | None = None
    milestone_count: int | None = None
    recovery_lever_count: int | None = None
    field_question_count: int | None = None
    parser_warning_count: int | None = None
    rows_dropped_or_skipped: int | None = None
    total_float_days: float | None = None
    critical_path_activity_count: int | None = None
    risk_flags: list[str] = Field(default_factory=list)
    top_drivers: list[ScheduleDriver] = Field(default_factory=list)
    source_file: str | None = None
    trust: TrustIndicator
    provenance: list[SourceArtifactRef] = Field(default_factory=list)


class MetricVariance(BaseModel):
    metric_name: str
    current_value: float | None = None
    comparison_value: float | None = None
    absolute_change: float | None = None
    percent_change: float | None = None
    trend_direction: Literal["up", "down", "flat"] = "flat"


class FinancialSummary(BaseModel):
    project_slug: str
    report_month: str | None = None
    comparison_month: str | None = None
    snapshot_timestamp: str | None = None
    snapshot_id: int | None = None
    snapshot_version: int | None = None
    parse_status: str | None = None
    completeness_score: float | None = None
    completeness_label: str | None = None
    trusted: bool = False
    comparison_eligible: bool = False
    trust_tier: Literal["high", "partial", "low", "missing"] = "missing"
    trust_reasons: list[str] = Field(default_factory=list)
    metrics: dict[str, float | None] = Field(default_factory=dict)
    variances: list[MetricVariance] = Field(default_factory=list)
    executive_summary: str = ""
    key_findings: list[str] = Field(default_factory=list)
    flags: list[str] = Field(default_factory=list)
    trust: TrustIndicator
    source_file_name: str | None = None
    source_file_path: str | None = None
    provenance: list[SourceArtifactRef] = Field(default_factory=list)


class ScheduleDelta(BaseModel):
    current_finish_date: str | None = None
    previous_finish_date: str | None = None
    finish_date_movement_days: int | None = None
    current_float_days: float | None = None
    previous_float_days: float | None = None
    float_movement_days: float | None = None
    float_direction: Literal["compression", "expansion", "flat", "unknown"] = "unknown"
    critical_path_changed: bool = False
    current_critical_path_activity_count: int | None = None
    previous_critical_path_activity_count: int | None = None
    summary: str = ""


class FinancialDelta(BaseModel):
    current_cost_variance: float | None = None
    previous_cost_variance: float | None = None
    cost_variance_change: float | None = None
    current_margin_percent: float | None = None
    previous_margin_percent: float | None = None
    margin_movement: float | None = None
    summary: str = ""


class RiskDelta(BaseModel):
    new_risks: list[str] = Field(default_factory=list)
    resolved_risks: list[str] = Field(default_factory=list)
    worsening_signals: list[str] = Field(default_factory=list)
    summary: str = ""


class ProjectDeltaDetails(BaseModel):
    schedule: ScheduleDelta = Field(default_factory=ScheduleDelta)
    financial: FinancialDelta = Field(default_factory=FinancialDelta)
    risk: RiskDelta = Field(default_factory=RiskDelta)
    summary: str = ""


class HealthAssessment(BaseModel):
    health_score: float
    risk_level: RiskLevel
    score: float
    tier: HealthTier
    rationale: list[str]
    required_actions: list[RecommendedAction]
    recommended_actions: list[RecommendedAction]


class ChangeNote(BaseModel):
    source: Literal["schedule", "financial", "cross_source"]
    summary: str


class ProjectSnapshot(BaseModel):
    identity: ProjectIdentity
    canonical_project_id: str
    canonical_project_code: str
    project_name: str
    domain: SurfaceDomain = "professional"
    source_keys: list[str] = Field(default_factory=list)
    source_project_keys: dict[str, str] = Field(default_factory=dict)
    snapshot_timestamp: str
    schedule: ScheduleSummary | None = None
    financial: FinancialSummary | None = None
    delta: ProjectDeltaDetails = Field(default_factory=ProjectDeltaDetails)
    health: HealthAssessment
    top_issues: list[IssueDriver] = Field(default_factory=list)
    recommended_actions: list[RecommendedAction] = Field(default_factory=list)
    latest_notable_changes: list[ChangeNote] = Field(default_factory=list)
    executive_summary: str
    provenance: list[SourceArtifactRef] = Field(default_factory=list)
    missing_data_flags: list[str] = Field(default_factory=list)
    trust_indicator: TrustIndicator
    comparison_status: ComparisonTrustStatus = "unavailable"
    comparison_run_id: str | None = None
    attention_rank: int | None = None
    attention_score: float | None = None


class PortfolioSummary(BaseModel):
    generated_at: str
    project_count: int
    active_project_count: int
    tier_counts: dict[str, int]
    average_health_score: float | None = None
    overall_posture: str
    risk_distribution: dict[str, int] = Field(default_factory=dict)
    top_at_risk_projects: list[str] = Field(default_factory=list)
    top_5_at_risk_projects: list[str] = Field(default_factory=list)
    cross_project_risk_themes: list[str] = Field(default_factory=list)
    biggest_movers: list[str] = Field(default_factory=list)
    key_actions_this_week: list[str] = Field(default_factory=list)
    portfolio_changes: list[str] = Field(default_factory=list)
    project_rankings: list[ProjectSnapshot] = Field(default_factory=list)
    provenance: list[SourceArtifactRef] = Field(default_factory=list)
    comparison_trust: ComparisonTrust = Field(
        default_factory=lambda: ComparisonTrust(
            status="unavailable",
            label="Delta baseline unavailable",
            detail="No prior distinct run is available yet, so change-sensitive ranking is suppressed.",
            delta_ranking_enabled=False,
            reason_code="no_prior_run",
            ranking_authority="trust_bounded",
            ranking_label="Trust-bounded ranking",
            ranking_detail="Current-run risk, health, and trust signals are visible, but delta-driven ranking is not authoritative yet.",
            baseline_label="No prior comparison baseline",
            baseline_detail="No trusted prior comparison run is available yet, so change-sensitive ranking is suppressed.",
        )
    )
    domain_coverage: list[DomainCoverage] = Field(default_factory=list)


class ControlTowerHeadline(BaseModel):
    overall_posture: str
    intervention_count: int
    high_risk_count: int
    immediate_action_count: int
    readiness_status: str
    readiness_summary: str
    arena_candidate_count: int


class ControlTowerAttentionItem(BaseModel):
    canonical_project_code: str
    project_name: str
    domain: SurfaceDomain
    posture: str
    risk_level: RiskLevel
    tier: HealthTier
    health_score: float
    what_changed: str
    why_it_matters: str
    required_action: str
    action_owner: str
    action_timing: str
    cause: str
    impact: str
    schedule_signal: str
    current_finish_date: str | None = None
    finish_delta_days: int | None = None
    ranking_reason: str
    trust_status: Literal["high", "partial", "low", "missing"]
    comparison_label: str = ""
    comparison_detail: str = ""
    drilldown_path: str
    compare_path: str
    arena_add_path: str
    arena_remove_path: str
    arena_promoted: bool = False
    arena_group: str = "Operational Priorities"


class SecondarySurfaceLink(BaseModel):
    label: str
    path: str
    detail: str


class SurfaceScanCard(BaseModel):
    key: str
    label: str
    summary: str
    detail: str = ""
    item_count: int = 0
    project_code: str | None = None


class NarrativeBullet(BaseModel):
    canonical_project_code: str | None = None
    project_name: str
    who: str
    what: str
    why: str
    action: str
    summary: str
    detail: str = ""
    cause: str = ""
    impact: str = ""
    timing: str = ""
    owner: str | None = None
    current_finish_date: str | None = None
    finish_delta_days: int | None = None

    def model_post_init(self, __context: Any) -> None:
        missing = [
            field_name.upper()
            for field_name, value in (
                ("who", self.who),
                ("what", self.what),
                ("why", self.why),
                ("action", self.action),
            )
            if not str(value or "").strip()
        ]
        if missing:
            raise ValueError(f"Narrative contract incomplete for {self.project_name}: missing {', '.join(missing)}")


class NarrativeSection(BaseModel):
    key: str
    label: str
    title: str
    summary: str
    item_count: int
    lead_project_code: str | None = None
    default_open: bool = False
    items: list[NarrativeBullet] = Field(default_factory=list)


class ControlTowerView(BaseModel):
    generated_at: str
    headline: ControlTowerHeadline
    comparison_trust: ComparisonTrust
    executive_scan: list[SurfaceScanCard] = Field(default_factory=list)
    material_changes_section: NarrativeSection
    required_actions_section: NarrativeSection
    rising_risks_section: NarrativeSection
    watch_items_section: NarrativeSection
    domain_coverage: list[DomainCoverage] = Field(default_factory=list)
    top_attention: list[ControlTowerAttentionItem] = Field(default_factory=list)
    intervention_required: list[ControlTowerAttentionItem] = Field(default_factory=list)
    arena_candidates: list[ControlTowerAttentionItem] = Field(default_factory=list)
    selected_arena_codes: list[str] = Field(default_factory=list)
    arena_path: str = "/arena"
    arena_export_path: str = "/arena/export"
    arena_artifact_path: str = "/arena/export/artifact.md"
    secondary_links: list[SecondarySurfaceLink] = Field(default_factory=list)


class ArenaMetric(BaseModel):
    label: str
    value: str


class ArenaItem(BaseModel):
    canonical_project_code: str
    project_name: str
    domain: SurfaceDomain
    group: str
    posture: str
    headline: str
    risk_statement: str
    why_it_matters_statement: str = ""
    action_statement: str
    change_statement: str
    cause_statement: str = ""
    impact_statement: str = ""
    action_timing: str = ""
    schedule_signal: str = ""
    current_finish_date: str | None = None
    finish_delta_days: int | None = None
    comparison_label: str = ""
    comparison_detail: str = ""
    metrics: list[ArenaMetric] = Field(default_factory=list)
    evidence_points: list[str] = Field(default_factory=list)
    move_up_path: str | None = None
    move_down_path: str | None = None
    remove_path: str
    drilldown_path: str
    compare_path: str


class ArenaView(BaseModel):
    generated_at: str
    title: str
    subtitle: str
    export_title: str
    export_path: str
    artifact_title: str = "Arena Executive Handoff"
    artifact_path: str = "/arena/export/artifact.md"
    scope_summary: str = ""
    selection_summary: str = ""
    promotion_summary: str = ""
    headline_posture: str = ""
    executive_scan: list[SurfaceScanCard] = Field(default_factory=list)
    material_changes_section: NarrativeSection
    why_it_matters_section: NarrativeSection
    required_actions_section: NarrativeSection
    rising_risks_section: NarrativeSection
    comparison_trust: ComparisonTrust
    items: list[ArenaItem] = Field(default_factory=list)
    selected_arena_codes: list[str] = Field(default_factory=list)
    empty_state: str


class GeneratedNote(BaseModel):
    note_kind: NoteKind
    canonical_project_code: str | None = None
    title: str
    frontmatter: dict[str, Any]
    body: str
    output_path: Path
    preview_path: Path | None = None
    versioned_output_paths: list[Path] = Field(default_factory=list)
    wikilinks: list[str] = Field(default_factory=list)

    def full_markdown(self) -> str:
        return self.body


class ProjectDelta(BaseModel):
    project_id: str
    delta: ProjectDeltaDetails


class ExportRecord(BaseModel):
    run_id: str
    generated_at: str
    preview_only: bool
    notes: list[GeneratedNote]
    vault_root: str
    status: Literal["success", "partial", "failed"]
    issues: list[str] = Field(default_factory=list)
    source_artifacts: list[SourceArtifactRef] = Field(default_factory=list)
    previous_run_id: str | None = None
    portfolio_snapshot: PortfolioSummary | None = None
    project_snapshots: list[ProjectSnapshot] = Field(default_factory=list)
    project_deltas: list[ProjectDelta] = Field(default_factory=list)


def utc_now_iso() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
