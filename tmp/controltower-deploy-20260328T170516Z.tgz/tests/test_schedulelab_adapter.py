from __future__ import annotations

from controltower.adapters.schedulelab import ScheduleLabAdapter


def test_schedulelab_adapter_loads_project(sample_schedulelab_root):
    adapter = ScheduleLabAdapter(sample_schedulelab_root)
    projects = adapter.list_projects()

    assert len(projects) == 1
    project = projects[0]
    assert project.project_code == "AURORA_HILLS"
    assert project.health_score == 73.0
    assert project.open_finish_count == 7
    assert project.top_drivers[0].label.startswith("A-101")
    assert not adapter.validate()

