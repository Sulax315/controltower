from __future__ import annotations

from controltower.config import load_config
from controltower.services.meeting_readiness import verify_meeting_readiness


def test_meeting_readiness_contract_passes(sample_config_path):
    config = load_config(sample_config_path)

    result = verify_meeting_readiness(config, ["AURORA_HILLS"])

    assert result["status"] == "pass"
    assert result["checks"]["root_leads_with_posture_change_action_risk"] is True
    assert result["checks"]["root_first_screen_preserves_executive_hierarchy"] is True
    assert result["checks"]["root_major_sections_are_progressively_disclosed"] is True
    assert result["checks"]["root_sections_obey_project_decision_contract"] is True
    assert result["checks"]["root_collapsible_sections_lead_with_project_codes"] is True
    assert result["checks"]["root_required_actions_visible_without_expansion"] is True
    assert result["checks"]["root_schedule_signal_visible_without_expansion"] is True
    assert result["checks"]["arena_preserves_executive_narrative_order"] is True
    assert result["checks"]["arena_sections_obey_project_decision_contract"] is True
    assert result["checks"]["arena_collapsible_sections_lead_with_project_codes"] is True
    assert result["checks"]["arena_schedule_signal_visible_without_expansion"] is True
    assert result["checks"]["arena_is_more_presentation_oriented_than_root"] is True
    assert result["checks"]["artifact_preserves_narrative_contract"] is True
    assert result["checks"]["artifact_preserves_executive_packet_discipline"] is True
