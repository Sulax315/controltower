from __future__ import annotations

from pathlib import Path
from urllib.parse import urlencode

from controltower.adapters.profitintel import ProfitIntelAdapter
from controltower.adapters.schedulelab import ScheduleLabAdapter
from controltower.config import ControlTowerConfig
from controltower.domain.models import (
    ArenaItem,
    ArenaMetric,
    ArenaView,
    ComparisonTrust,
    ControlTowerAttentionItem,
    ControlTowerHeadline,
    ControlTowerView,
    DomainCoverage,
    ExportRecord,
    NarrativeBullet,
    NarrativeSection,
    PortfolioSummary,
    ProjectDelta,
    ProjectIdentity,
    ProjectSnapshot,
    SecondarySurfaceLink,
    SourceArtifactRef,
    SurfaceScanCard,
    utc_now_iso,
)
from controltower.obsidian.exporter import write_export_bundle
from controltower.render.markdown import (
    render_arena_export_artifact,
    render_portfolio_summary,
    render_project_dossier,
    render_project_weekly_brief,
    validate_markdown_templates,
)
from controltower.services.delta import (
    compute_project_deltas,
    describe_comparison_trust,
    index_projects_by_id,
    load_previous_run_record,
    load_run_history,
    load_run_record,
    record_matches_current,
    select_comparison_run_record,
)
from controltower.services.health import assess_project_health, posture_text
from controltower.services.identity_reconciliation import IdentityReconciliationService
from controltower.services.runtime_state import LATEST_RELEASE_JSON, RELEASE_ROOT_NAME, read_json


class ControlTowerService:
    def __init__(self, config: ControlTowerConfig) -> None:
        self.config = config
        validate_markdown_templates()
        self.identity_registry = IdentityReconciliationService.load(config.identity.registry_path)
        self.schedulelab = ScheduleLabAdapter(config.sources.schedulelab.published_root)
        self.profitintel = ProfitIntelAdapter(
            config.sources.profitintel.database_path,
            validation_search_roots=config.sources.profitintel.validation_search_roots,
        )

    def validate_sources(self) -> list[str]:
        return self.schedulelab.validate() + self.profitintel.validate()

    def build_projects(self) -> list[ProjectSnapshot]:
        projects, _comparison_trust = self._build_ranked_projects()
        return projects

    def build_portfolio(self) -> PortfolioSummary:
        projects, comparison_trust = self._build_ranked_projects()
        generated_at = utc_now_iso()
        tier_counts = {
            "healthy": sum(1 for project in projects if project.health.tier == "healthy"),
            "watch": sum(1 for project in projects if project.health.tier == "watch"),
            "at_risk": sum(1 for project in projects if project.health.tier == "at_risk"),
            "critical": sum(1 for project in projects if project.health.tier == "critical"),
        }
        risk_distribution = {
            "LOW": sum(1 for project in projects if project.health.risk_level == "LOW"),
            "MEDIUM": sum(1 for project in projects if project.health.risk_level == "MEDIUM"),
            "HIGH": sum(1 for project in projects if project.health.risk_level == "HIGH"),
        }
        avg = round(sum(project.health.health_score for project in projects) / len(projects), 1) if projects else None
        top_at_risk = [project.project_name for project in projects if project.health.risk_level == "HIGH"][:5]
        key_actions = [
            f"{project.project_name}: {project.health.required_actions[0].action}"
            for project in projects
            if project.health.required_actions
        ][:8]
        provenance: list[SourceArtifactRef] = []
        for project in projects:
            provenance.extend(project.provenance)
        return PortfolioSummary(
            generated_at=generated_at,
            project_count=len(projects),
            active_project_count=len(projects),
            tier_counts=tier_counts,
            average_health_score=avg,
            overall_posture=posture_text(projects),
            risk_distribution=risk_distribution,
            top_at_risk_projects=top_at_risk,
            top_5_at_risk_projects=top_at_risk,
            cross_project_risk_themes=self._cross_project_risk_themes(projects),
            biggest_movers=self._portfolio_changes(projects, comparison_trust),
            key_actions_this_week=key_actions,
            portfolio_changes=self._portfolio_changes(projects, comparison_trust)[:5],
            project_rankings=projects,
            provenance=_dedupe_provenance(provenance)[:20],
            comparison_trust=comparison_trust,
            domain_coverage=self._domain_coverage(projects),
        )
 
    def build_control_tower(self, selected_arena_codes: list[str] | None = None) -> ControlTowerView:
        portfolio = self.build_portfolio()
        selected_codes = self._normalize_selection(selected_arena_codes, portfolio.project_rankings)
        top_attention = [self._build_attention_item(project, selected_codes, portfolio.comparison_trust) for project in portfolio.project_rankings[:8]]
        intervention_required = [
            self._build_attention_item(project, selected_codes, portfolio.comparison_trust)
            for project in portfolio.project_rankings
            if project.health.risk_level == "HIGH" or any(action.priority == "high" for action in project.health.required_actions)
        ][:6]
        arena_candidates = [
            self._build_attention_item(project, selected_codes, portfolio.comparison_trust)
            for project in portfolio.project_rankings
            if project.health.risk_level == "HIGH"
            or project.trust_indicator.status != "high"
            or (portfolio.comparison_trust.delta_ranking_enabled and self._delta_attention_score(project) > 0)
        ][:6]
        watch_items = [
            self._build_attention_item(project, selected_codes, portfolio.comparison_trust)
            for project in portfolio.project_rankings
            if project.health.risk_level == "MEDIUM" or project.health.tier == "watch"
        ][:6]
        readiness_status, readiness_summary = self._latest_release_posture()
        immediate_action_count = sum(
            1 for project in portfolio.project_rankings if any(action.priority == "high" for action in project.health.required_actions)
        )
        headline = ControlTowerHeadline(
            overall_posture=portfolio.overall_posture,
            intervention_count=len(intervention_required),
            high_risk_count=portfolio.risk_distribution.get("HIGH", 0),
            immediate_action_count=immediate_action_count,
            readiness_status=readiness_status,
            readiness_summary=readiness_summary,
            arena_candidate_count=len(arena_candidates),
        )
        material_changes_section = self._build_narrative_section(
            key="material-changes",
            label="What changed materially",
            title="Material Changes",
            items=[self._change_bullet(item) for item in top_attention[:4]],
            empty_summary="No material change is leading the current run.",
        )
        required_actions_section = self._build_narrative_section(
            key="required-actions",
            label="What requires action or decision now",
            title="Required Actions / Decisions",
            items=[self._action_bullet(item) for item in intervention_required[:4]],
            empty_summary="No immediate decision or action is leading the current run.",
        )
        rising_risks_section = self._build_narrative_section(
            key="rising-risks",
            label="Where risk is rising",
            title="Rising Risks / Watch Items",
            items=[self._risk_bullet(item) for item in top_attention if item.risk_level == "HIGH"][:4],
            empty_summary="No rising high-risk signal is leading the current run.",
        )
        watch_items_section = self._build_narrative_section(
            key="watch-items",
            label="Watch items",
            title="Watch Items",
            items=[self._change_bullet(item) for item in watch_items[:4]],
            empty_summary="No watch item is leading the current run.",
        )
        executive_scan = self._build_control_tower_scan_cards(
            headline=headline,
            comparison_trust=portfolio.comparison_trust,
            material_changes=material_changes_section,
            required_actions=required_actions_section,
            rising_risks=rising_risks_section,
            watch_items=watch_items_section,
        )
        return ControlTowerView(
            generated_at=portfolio.generated_at,
            headline=headline,
            comparison_trust=portfolio.comparison_trust,
            executive_scan=executive_scan,
            material_changes_section=material_changes_section,
            required_actions_section=required_actions_section,
            rising_risks_section=rising_risks_section,
            watch_items_section=watch_items_section,
            domain_coverage=portfolio.domain_coverage,
            top_attention=top_attention,
            intervention_required=intervention_required,
            arena_candidates=arena_candidates,
            selected_arena_codes=selected_codes,
            arena_path=self._arena_path(selected_codes),
            arena_export_path=self._arena_path(selected_codes, export_mode=True),
            arena_artifact_path=self._arena_artifact_path(selected_codes),
            secondary_links=[
                SecondarySurfaceLink(
                    label="Project Ledger",
                    path="/projects",
                    detail="Supporting drill-down for the full ranked list and comparison pages.",
                ),
                SecondarySurfaceLink(
                    label="Run History",
                    path="/runs",
                    detail="Audit prior exports, manifests, and runtime output roots.",
                ),
                SecondarySurfaceLink(
                    label="Latest Export",
                    path="/exports/latest",
                    detail="Review the latest deterministic export bundle and note paths.",
                ),
                SecondarySurfaceLink(
                    label="Diagnostics",
                    path="/diagnostics",
                    detail="Inspect release readiness, runtime artifacts, and environment provenance.",
                ),
            ],
        )

    def build_arena(self, selected_arena_codes: list[str] | None = None) -> ArenaView:
        portfolio = self.build_portfolio()
        selected_codes = self._normalize_selection(selected_arena_codes, portfolio.project_rankings)
        project_lookup = {project.canonical_project_code: project for project in portfolio.project_rankings}
        items: list[ArenaItem] = []
        selected_projects: list[ProjectSnapshot] = []
        for index, code in enumerate(selected_codes):
            project = project_lookup.get(code)
            if project is None:
                continue
            selected_projects.append(project)
            items.append(
                ArenaItem(
                    canonical_project_code=project.canonical_project_code,
                    project_name=project.project_name,
                    domain=project.domain,
                    group="Professional Portfolio" if project.domain == "professional" else "Personal Operating Items",
                    posture=project.executive_summary,
                    headline=self._arena_headline(project),
                    risk_statement=self._arena_risk_statement(project),
                    why_it_matters_statement=self._arena_why_it_matters(project),
                    action_statement=self._arena_action_statement(project),
                    change_statement=self._arena_change_statement(project, portfolio.comparison_trust),
                    comparison_label=portfolio.comparison_trust.ranking_label,
                    comparison_detail=self._project_comparison_detail(project, portfolio.comparison_trust),
                    metrics=self._arena_metrics(project),
                    evidence_points=self._arena_evidence(project),
                    move_up_path=self._arena_path(self._move_selection(selected_codes, code, -1)) if index > 0 else None,
                    move_down_path=self._arena_path(self._move_selection(selected_codes, code, 1))
                    if index < len(selected_codes) - 1
                    else None,
                    remove_path=self._arena_path([item for item in selected_codes if item != code]),
                    drilldown_path=f"/projects/{project.canonical_project_code}",
                    compare_path=f"/projects/{project.canonical_project_code}/compare",
                )
            )
        headline_posture = posture_text(selected_projects) if selected_projects else portfolio.overall_posture
        material_changes_section = self._build_narrative_section(
            key="material-changes",
            label="What changed",
            title="Material Changes",
            items=[self._arena_change_bullet(item) for item in items[:4]],
            empty_summary="No promoted item is in the meeting slate yet.",
        )
        why_it_matters_section = self._build_narrative_section(
            key="why-it-matters",
            label="Why it matters",
            title="Why It Matters",
            items=[self._arena_impact_bullet(item) for item in items[:4]],
            empty_summary="Why-it-matters narrative will appear once an item is promoted.",
        )
        required_actions_section = self._build_narrative_section(
            key="required-actions",
            label="What needs decision",
            title="Required Actions / Decisions",
            items=[self._arena_action_required_bullet(item) for item in items[:4]],
            empty_summary="No decision-ready item is currently selected.",
        )
        rising_risks_section = self._build_narrative_section(
            key="rising-risks",
            label="Rising risks",
            title="Rising Risks / Watch Items",
            items=[self._arena_risk_bullet(item) for item in items[:4]],
            empty_summary="No rising risk is leading the meeting slate.",
        )
        executive_scan = self._build_arena_scan_cards(
            headline_posture=headline_posture,
            material_changes=material_changes_section,
            why_it_matters=why_it_matters_section,
            required_actions=required_actions_section,
            rising_risks=rising_risks_section,
        )
        return ArenaView(
            generated_at=portfolio.generated_at,
            title="Arena",
            subtitle="Room-ready narrative surface for live reviews, screenshares, and executive handoffs.",
            export_title="Print / PDF view is presentation-only. Use the authoritative Markdown artifact for handoff.",
            export_path=self._arena_path(selected_codes, export_mode=True),
            artifact_title="Arena Executive Handoff",
            artifact_path=self._arena_artifact_path(selected_codes),
            scope_summary=self._arena_scope_summary(selected_codes),
            selection_summary=self._arena_selection_summary(selected_codes),
            promotion_summary="Agenda order follows the current Control Tower promotion sequence.",
            headline_posture=headline_posture,
            executive_scan=executive_scan,
            material_changes_section=material_changes_section,
            why_it_matters_section=why_it_matters_section,
            required_actions_section=required_actions_section,
            rising_risks_section=rising_risks_section,
            comparison_trust=portfolio.comparison_trust,
            items=items,
            selected_arena_codes=selected_codes,
            empty_state="No Control Tower items have been promoted into Arena yet. Promote candidates from the main surface first.",
        )

    def build_arena_export_artifact(self, selected_arena_codes: list[str] | None = None) -> tuple[ArenaView, str, str]:
        arena = self.build_arena(selected_arena_codes)
        filename = self._arena_artifact_filename(arena.selected_arena_codes)
        body = render_arena_export_artifact(arena)
        return arena, filename, body

    def build_runtime_coherence_snapshot(self, selected_arena_codes: list[str] | None = None) -> dict[str, object]:
        projects, comparison_trust = self._build_ranked_projects()
        current_projects = [(project.identity, project.schedule, project.financial) for project in projects]
        comparison_record = select_comparison_run_record(self.config.runtime.state_root, current_projects)
        history = load_run_history(self.config.runtime.state_root)
        latest_record = history[0] if history else None
        selected_codes = self._normalize_selection(selected_arena_codes, projects)
        arena = self.build_arena(selected_codes)
        status_counts = {
            "trusted": sum(1 for project in projects if project.comparison_status == "trusted"),
            "contained": sum(1 for project in projects if project.comparison_status == "contained"),
            "unavailable": sum(1 for project in projects if project.comparison_status == "unavailable"),
        }
        return {
            "generated_at": arena.generated_at,
            "comparison_trust": comparison_trust.model_dump(mode="json"),
            "comparison_run_id": comparison_record.run_id if comparison_record else None,
            "comparison_run_matches_surface": (comparison_record.run_id if comparison_record else None) == comparison_trust.comparison_run_id,
            "delta_ranking_consistent_with_baseline": comparison_trust.delta_ranking_enabled == bool(comparison_record),
            "latest_run_id": latest_record.run_id if latest_record else None,
            "latest_run_matches_current": record_matches_current(latest_record, current_projects) if latest_record else False,
            "no_distinct_prior_baseline": comparison_trust.reason_code == "no_distinct_prior_run",
            "contained_blocks_authoritative_delta": not (
                comparison_trust.reason_code == "no_distinct_prior_run" and comparison_trust.delta_ranking_enabled
            ),
            "ranking_authority": comparison_trust.ranking_authority,
            "selected_arena_codes": list(arena.selected_arena_codes),
            "arena_item_codes": [item.canonical_project_code for item in arena.items],
            "arena_export_path": arena.export_path,
            "arena_artifact_path": arena.artifact_path,
            "project_comparison_status_counts": status_counts,
        }

    def build_notes(self, project_code: str | None = None) -> tuple[PortfolioSummary, list]:
        portfolio = self.build_portfolio()
        projects = portfolio.project_rankings
        if project_code:
            projects = [project for project in portfolio.project_rankings if project.canonical_project_code == project_code]
        notes = [render_portfolio_summary(portfolio, self.config.obsidian)]
        for project in projects:
            notes.append(render_project_dossier(project, self.config.obsidian, portfolio.generated_at))
            notes.append(render_project_weekly_brief(project, self.config.obsidian, portfolio.generated_at))
        return portfolio, notes

    def export_notes(self, *, preview_only: bool, project_code: str | None = None) -> ExportRecord:
        portfolio, notes = self.build_notes(project_code=project_code)
        issues = self.validate_sources()
        previous_record = load_previous_run_record(self.config.runtime.state_root)
        selected_projects = portfolio.project_rankings
        if project_code:
            selected_projects = [project for project in portfolio.project_rankings if project.canonical_project_code == project_code]
        return write_export_bundle(
            run_id=portfolio.generated_at.replace(":", "-"),
            generated_at=portfolio.generated_at,
            notes=notes,
            vault_root=self.config.obsidian.vault_root,
            state_root=self.config.runtime.state_root,
            preview_only=preview_only,
            timestamped_weekly_notes=self.config.obsidian.timestamped_weekly_notes,
            exports_folder=self.config.obsidian.exports_folder,
            source_artifacts=portfolio.provenance,
            issues=issues,
            previous_run_id=previous_record.run_id if previous_record else None,
            portfolio_snapshot=portfolio,
            project_snapshots=selected_projects,
            project_deltas=[ProjectDelta(project_id=project.canonical_project_id, delta=project.delta) for project in selected_projects],
        )

    def list_runs(self) -> list[ExportRecord]:
        return load_run_history(self.config.runtime.state_root)

    def get_run(self, run_id: str) -> ExportRecord | None:
        return load_run_record(self.config.runtime.state_root, run_id)

    def get_project_compare(self, project_code: str) -> dict[str, object] | None:
        projects, comparison_trust = self._build_ranked_projects()
        current = next((item for item in projects if item.canonical_project_code == project_code), None)
        if current is None:
            return None
        previous_record = select_comparison_run_record(
            self.config.runtime.state_root,
            [(project.identity, project.schedule, project.financial) for project in projects],
        )
        previous_project = None
        if previous_record:
            previous_project = next(
                (item for item in previous_record.project_snapshots if item.canonical_project_id == current.canonical_project_id),
                None,
            )
        return {
            "current": current,
            "previous": previous_project,
            "previous_run_id": previous_record.run_id if previous_record else None,
            "comparison_trust": comparison_trust,
        }

    def _build_ranked_projects(self) -> tuple[list[ProjectSnapshot], ComparisonTrust]:
        merged_entries = self._merge_projects()
        current_projects = [(entry["identity"], entry.get("schedule"), entry.get("financial")) for entry in merged_entries]
        comparison_trust = describe_comparison_trust(self.config.runtime.state_root, current_projects)
        previous_record = select_comparison_run_record(self.config.runtime.state_root, current_projects)
        previous_projects = index_projects_by_id(previous_record)
        project_deltas = {
            item.project_id: item.delta
            for item in compute_project_deltas(
                current_projects,
                previous_projects,
            )
        }

        projects: list[ProjectSnapshot] = []
        for entry in merged_entries:
            identity: ProjectIdentity = entry["identity"]
            schedule = entry.get("schedule")
            financial = entry.get("financial")
            previous_project = previous_projects.get(identity.canonical_project_id)
            delta = project_deltas[identity.canonical_project_id]
            health, issues, actions, changes, executive_summary, trust, missing = assess_project_health(
                project_name=identity.project_name,
                schedule=schedule,
                financial=financial,
                delta=delta,
            )
            provenance: list[SourceArtifactRef] = []
            if schedule:
                provenance.extend(schedule.provenance)
            if financial:
                provenance.extend(financial.provenance)
            snapshot_timestamp = (
                (schedule.run_timestamp if schedule and schedule.run_timestamp else None)
                or (financial.snapshot_timestamp if financial and financial.snapshot_timestamp else None)
                or utc_now_iso()
            )
            source_project_keys = dict(entry["source_project_keys"])
            source_keys = sorted(entry["source_keys"])
            projects.append(
                ProjectSnapshot(
                    identity=identity.model_copy(update={"source_keys": source_keys}),
                    canonical_project_id=identity.canonical_project_id,
                    canonical_project_code=identity.canonical_project_code,
                    project_name=identity.project_name,
                    domain=self._classify_domain(source_keys),
                    source_keys=source_keys,
                    source_project_keys=source_project_keys,
                    snapshot_timestamp=snapshot_timestamp,
                    schedule=schedule,
                    financial=financial,
                    delta=delta,
                    health=health,
                    top_issues=issues,
                    recommended_actions=actions,
                    latest_notable_changes=changes,
                    executive_summary=executive_summary,
                    provenance=provenance,
                    missing_data_flags=missing,
                    trust_indicator=trust,
                    comparison_status="trusted" if previous_project else ("unavailable" if comparison_trust.status == "trusted" else comparison_trust.status),
                    comparison_run_id=previous_record.run_id if previous_project and previous_record else None,
                )
            )

        ranked_projects = sorted(
            projects,
            key=lambda item: (-self._attention_score(item, comparison_trust), item.health.health_score, item.project_name),
        )
        result: list[ProjectSnapshot] = []
        for rank, project in enumerate(ranked_projects, start=1):
            result.append(
                project.model_copy(
                    update={
                        "attention_rank": rank,
                        "attention_score": self._attention_score(project, comparison_trust),
                    }
                )
            )
        return result, comparison_trust

    def _merge_projects(self) -> list[dict]:
        schedule_projects = self.schedulelab.list_projects()
        financial_projects = self.profitintel.list_projects()
        merged: dict[str, dict] = {}

        for schedule in schedule_projects:
            identity = self.identity_registry.resolve("schedulelab", schedule.project_code, schedule.project_name)
            bucket = merged.setdefault(
                identity.canonical_project_id,
                {
                    "identity": identity,
                    "schedule": None,
                    "financial": None,
                    "source_keys": set(identity.source_keys),
                    "source_project_keys": {},
                },
            )
            bucket["schedule"] = schedule
            bucket["source_keys"].add(f"schedulelab:{schedule.project_code}")
            bucket["source_project_keys"]["schedulelab"] = schedule.project_code
            bucket["identity"] = _merge_identity(bucket["identity"], identity)

        for financial in financial_projects:
            identity = self.identity_registry.resolve("profitintel", financial.project_slug, financial.project_slug)
            bucket = merged.setdefault(
                identity.canonical_project_id,
                {
                    "identity": identity,
                    "schedule": None,
                    "financial": None,
                    "source_keys": set(identity.source_keys),
                    "source_project_keys": {},
                },
            )
            bucket["financial"] = financial
            bucket["source_keys"].add(f"profitintel:{financial.project_slug}")
            bucket["source_project_keys"]["profitintel"] = financial.project_slug
            bucket["identity"] = _merge_identity(bucket["identity"], identity)

        return [merged[key] for key in sorted(merged.keys())]

    def _cross_project_risk_themes(self, projects: list[ProjectSnapshot]) -> list[str]:
        theme_counts: dict[str, int] = {}
        for project in projects:
            labels = [issue.label for issue in project.top_issues[:4]]
            for label in labels:
                theme_counts[label] = theme_counts.get(label, 0) + 1
        ranked = sorted(theme_counts.items(), key=lambda item: (-item[1], item[0]))
        return [f"{label} ({count})" for label, count in ranked[:5]]

    def _portfolio_changes(self, projects: list[ProjectSnapshot], comparison_trust: ComparisonTrust) -> list[str]:
        if not comparison_trust.delta_ranking_enabled:
            return [comparison_trust.detail]
        return [
            f"{project.project_name}: {project.delta.summary}"
            for project in projects
            if project.delta.summary and "baseline established" not in project.delta.summary.lower()
        ][:8]

    def _domain_coverage(self, projects: list[ProjectSnapshot]) -> list[DomainCoverage]:
        professional_count = sum(1 for project in projects if project.domain == "professional")
        personal_count = sum(1 for project in projects if project.domain == "personal")
        return [
            DomainCoverage(
                domain="professional",
                label="Professional / Project Control",
                available=professional_count > 0,
                item_count=professional_count,
                detail=(
                    "Current adapters cover schedule, cost, profit, and release posture."
                    if professional_count
                    else "No professional project-control entities resolved in the current run."
                ),
            ),
            DomainCoverage(
                domain="personal",
                label="Personal Operating Items",
                available=personal_count > 0,
                item_count=personal_count,
                detail=(
                    "Personal operating items are active in the current run."
                    if personal_count
                    else "Personal domain is not yet backed by a current adapter in this build, so Control Tower shows a bounded fallback state."
                ),
            ),
        ]

    def _build_attention_item(
        self,
        project: ProjectSnapshot,
        selected_codes: list[str],
        comparison_trust: ComparisonTrust,
    ) -> ControlTowerAttentionItem:
        why_it_matters = project.top_issues[0].detail if project.top_issues else project.executive_summary
        required_action = (
            project.health.required_actions[0].action
            if project.health.required_actions
            else "Maintain the current operating cadence and verify the next source publication."
        )
        action_owner = project.health.required_actions[0].owner_hint if project.health.required_actions else "PM"
        return ControlTowerAttentionItem(
            canonical_project_code=project.canonical_project_code,
            project_name=project.project_name,
            domain=project.domain,
            posture=project.executive_summary,
            risk_level=project.health.risk_level,
            tier=project.health.tier,
            health_score=project.health.health_score,
            what_changed=self._change_summary(project, comparison_trust),
            why_it_matters=why_it_matters,
            required_action=required_action,
            action_owner=action_owner,
            ranking_reason=self._ranking_reason(project),
            trust_status=project.trust_indicator.status,
            comparison_label=self._comparison_label_for_project(project),
            comparison_detail=self._project_comparison_detail(project, comparison_trust),
            drilldown_path=f"/projects/{project.canonical_project_code}",
            compare_path=f"/projects/{project.canonical_project_code}/compare",
            arena_add_path=self._arena_path(selected_codes + [project.canonical_project_code]),
            arena_remove_path=self._arena_path([code for code in selected_codes if code != project.canonical_project_code]),
            arena_promoted=project.canonical_project_code in selected_codes,
            arena_group="Professional Portfolio" if project.domain == "professional" else "Personal Operating Items",
        )

    def _build_narrative_section(
        self,
        *,
        key: str,
        label: str,
        title: str,
        items: list[NarrativeBullet],
        empty_summary: str,
        default_open: bool = False,
    ) -> NarrativeSection:
        if not items:
            return NarrativeSection(
                key=key,
                label=label,
                title=title,
                summary=empty_summary,
                item_count=0,
                default_open=default_open,
                items=[],
            )
        lead = items[0]
        summary = f"{self._count_phrase(len(items))}. {lead.project_name}: {self._brief_statement(lead.summary, max_words=12)}"
        return NarrativeSection(
            key=key,
            label=label,
            title=title,
            summary=summary,
            item_count=len(items),
            default_open=default_open,
            items=items,
        )

    def _build_control_tower_scan_cards(
        self,
        *,
        headline: ControlTowerHeadline,
        comparison_trust: ComparisonTrust,
        material_changes: NarrativeSection,
        required_actions: NarrativeSection,
        rising_risks: NarrativeSection,
        watch_items: NarrativeSection,
    ) -> list[SurfaceScanCard]:
        return [
            SurfaceScanCard(
                key="posture",
                label="Overall posture",
                summary=headline.overall_posture,
                detail=(
                    f"Release {headline.readiness_status.replace('_', ' ')}. "
                    f"{self._count_phrase(headline.high_risk_count)} high risk. "
                    f"{self._count_phrase(headline.immediate_action_count)} need action."
                ),
                item_count=headline.intervention_count,
            ),
            SurfaceScanCard(
                key="change",
                label="What changed materially",
                summary=(
                    self._brief_statement(material_changes.items[0].summary, max_words=12)
                    if material_changes.items
                    else self._brief_statement(material_changes.summary, max_words=12)
                ),
                detail=(
                    self._brief_statement(material_changes.items[0].detail, max_words=14)
                    if material_changes.items
                    else self._brief_statement(comparison_trust.ranking_detail, max_words=14)
                ),
                item_count=material_changes.item_count,
            ),
            SurfaceScanCard(
                key="action",
                label="What requires action or decision now",
                summary=(
                    self._brief_statement(required_actions.items[0].summary, max_words=12)
                    if required_actions.items
                    else self._brief_statement(required_actions.summary, max_words=12)
                ),
                detail=(
                    self._brief_statement(required_actions.items[0].detail, max_words=14)
                    if required_actions.items
                    else self._brief_statement(headline.readiness_summary, max_words=14)
                ),
                item_count=required_actions.item_count,
            ),
            SurfaceScanCard(
                key="risk",
                label="Where risk is rising",
                summary=(
                    self._brief_statement(rising_risks.items[0].summary, max_words=12)
                    if rising_risks.items
                    else self._brief_statement(rising_risks.summary, max_words=12)
                ),
                detail=(
                    self._brief_statement(rising_risks.items[0].detail, max_words=14)
                    if rising_risks.items
                    else self._brief_statement(watch_items.summary, max_words=14)
                ),
                item_count=rising_risks.item_count,
            ),
        ]

    def _build_arena_scan_cards(
        self,
        *,
        headline_posture: str,
        material_changes: NarrativeSection,
        why_it_matters: NarrativeSection,
        required_actions: NarrativeSection,
        rising_risks: NarrativeSection,
    ) -> list[SurfaceScanCard]:
        return [
            SurfaceScanCard(
                key="headline",
                label="Headline posture",
                summary=headline_posture,
                detail="Lead with posture and decision. Expand only if challenged.",
                item_count=0,
            ),
            SurfaceScanCard(
                key="change",
                label="What changed",
                summary=(
                    self._brief_statement(material_changes.items[0].summary, max_words=12)
                    if material_changes.items
                    else self._brief_statement(material_changes.summary, max_words=12)
                ),
                detail=(
                    self._brief_statement(material_changes.items[0].detail, max_words=14)
                    if material_changes.items
                    else ""
                ),
                item_count=material_changes.item_count,
            ),
            SurfaceScanCard(
                key="impact",
                label="Why it matters",
                summary=(
                    self._brief_statement(why_it_matters.items[0].summary, max_words=12)
                    if why_it_matters.items
                    else self._brief_statement(why_it_matters.summary, max_words=12)
                ),
                detail=(
                    self._brief_statement(why_it_matters.items[0].detail, max_words=14)
                    if why_it_matters.items
                    else ""
                ),
                item_count=why_it_matters.item_count,
            ),
            SurfaceScanCard(
                key="decision",
                label="What needs decision",
                summary=(
                    self._brief_statement(required_actions.items[0].summary, max_words=12)
                    if required_actions.items
                    else self._brief_statement(required_actions.summary, max_words=12)
                ),
                detail=(
                    self._brief_statement(required_actions.items[0].detail, max_words=14)
                    if required_actions.items
                    else self._brief_statement(rising_risks.summary, max_words=14)
                ),
                item_count=required_actions.item_count,
            ),
        ]

    def _change_bullet(self, item: ControlTowerAttentionItem) -> NarrativeBullet:
        return NarrativeBullet(
            canonical_project_code=item.canonical_project_code,
            project_name=item.project_name,
            summary=item.what_changed,
            detail=item.why_it_matters,
            owner=item.action_owner,
        )

    def _action_bullet(self, item: ControlTowerAttentionItem) -> NarrativeBullet:
        return NarrativeBullet(
            canonical_project_code=item.canonical_project_code,
            project_name=item.project_name,
            summary=f"{item.action_owner}: {item.required_action}",
            detail=item.why_it_matters,
            owner=item.action_owner,
        )

    def _risk_bullet(self, item: ControlTowerAttentionItem) -> NarrativeBullet:
        return NarrativeBullet(
            canonical_project_code=item.canonical_project_code,
            project_name=item.project_name,
            summary=item.why_it_matters,
            detail=f"Required action: {item.action_owner}: {item.required_action}",
            owner=item.action_owner,
        )

    def _arena_change_bullet(self, item: ArenaItem) -> NarrativeBullet:
        return NarrativeBullet(
            canonical_project_code=item.canonical_project_code,
            project_name=item.project_name,
            summary=item.change_statement,
            detail=item.why_it_matters_statement,
        )

    def _arena_impact_bullet(self, item: ArenaItem) -> NarrativeBullet:
        return NarrativeBullet(
            canonical_project_code=item.canonical_project_code,
            project_name=item.project_name,
            summary=item.why_it_matters_statement,
            detail=item.risk_statement,
        )

    def _arena_action_required_bullet(self, item: ArenaItem) -> NarrativeBullet:
        return NarrativeBullet(
            canonical_project_code=item.canonical_project_code,
            project_name=item.project_name,
            summary=item.action_statement,
            detail=item.why_it_matters_statement,
        )

    def _arena_risk_bullet(self, item: ArenaItem) -> NarrativeBullet:
        return NarrativeBullet(
            canonical_project_code=item.canonical_project_code,
            project_name=item.project_name,
            summary=item.risk_statement,
            detail=f"Decision needed: {item.action_statement}",
        )

    def _attention_score(self, project: ProjectSnapshot, comparison_trust: ComparisonTrust) -> float:
        risk_weight = {"HIGH": 40.0, "MEDIUM": 18.0, "LOW": 0.0}[project.health.risk_level]
        tier_weight = {"critical": 22.0, "at_risk": 14.0, "watch": 6.0, "healthy": 0.0}[project.health.tier]
        action_weight = sum({"high": 9.0, "medium": 5.0, "low": 2.0}[action.priority] for action in project.health.required_actions[:3])
        trust_weight = {"missing": 10.0, "low": 9.0, "partial": 5.0, "high": 0.0}[project.trust_indicator.status]
        base_pressure = max(0.0, 100.0 - project.health.health_score)
        delta_weight = self._delta_attention_score(project) if comparison_trust.delta_ranking_enabled else 0.0
        return round(risk_weight + tier_weight + action_weight + trust_weight + base_pressure + delta_weight, 1)

    def _delta_attention_score(self, project: ProjectSnapshot) -> float:
        score = 0.0
        if project.delta.schedule.finish_date_movement_days and project.delta.schedule.finish_date_movement_days > 0:
            score += min(18.0, float(project.delta.schedule.finish_date_movement_days) * 2.0)
        if project.delta.schedule.float_movement_days and project.delta.schedule.float_movement_days < 0:
            score += min(14.0, abs(project.delta.schedule.float_movement_days) * 3.0)
        if project.delta.financial.margin_movement and project.delta.financial.margin_movement < 0:
            score += min(12.0, abs(project.delta.financial.margin_movement) * 2.0)
        if project.delta.financial.cost_variance_change and project.delta.financial.cost_variance_change > 0:
            score += min(12.0, project.delta.financial.cost_variance_change / 10000.0)
        score += min(10.0, float(len(project.delta.risk.new_risks)) * 3.0)
        score += min(8.0, float(len(project.delta.risk.worsening_signals)) * 4.0)
        if project.delta.schedule.critical_path_changed:
            score += 5.0
        return round(score, 1)

    def _ranking_reason(self, project: ProjectSnapshot) -> str:
        reasons: list[str] = []
        if project.health.risk_level == "HIGH":
            reasons.append("high risk posture")
        if any(action.priority == "high" for action in project.health.required_actions):
            reasons.append("immediate action required")
        if project.trust_indicator.status != "high":
            reasons.append("trust-limited signals")
        if project.comparison_status == "trusted" and self._delta_attention_score(project) > 0:
            reasons.append("meaningful change since the prior trusted run")
        return ", ".join(reasons) if reasons else "steady but still tracked"

    def _change_summary(self, project: ProjectSnapshot, comparison_trust: ComparisonTrust) -> str:
        if project.comparison_status != "trusted":
            if comparison_trust.reason_code == "no_distinct_prior_run":
                return "No distinct trusted prior baseline exists yet, so delta-driven change scoring is contained."
            if comparison_trust.reason_code == "no_prior_run":
                return "No prior comparison run exists yet, so delta-driven change scoring is unavailable."
            return comparison_trust.ranking_detail
        if project.delta.summary:
            return project.delta.summary
        return "No material cross-run change was detected."

    def _classify_domain(self, source_keys: list[str]) -> str:
        lowered = {item.split(":", 1)[0].lower() for item in source_keys}
        if lowered.intersection({"personal", "family", "life", "household", "reminder"}):
            return "personal"
        return "professional"

    def _normalize_selection(self, selected_codes: list[str] | None, projects: list[ProjectSnapshot]) -> list[str]:
        available_codes = {project.canonical_project_code for project in projects}
        result: list[str] = []
        for code in selected_codes or []:
            cleaned = str(code).strip()
            if cleaned and cleaned in available_codes and cleaned not in result:
                result.append(cleaned)
        return result

    def _arena_path(self, selected_codes: list[str], *, export_mode: bool = False) -> str:
        path = "/arena/export" if export_mode else "/arena"
        if not selected_codes:
            return path
        return f"{path}?{urlencode([('selected', code) for code in selected_codes], doseq=True)}"

    def _arena_artifact_path(self, selected_codes: list[str]) -> str:
        path = "/arena/export/artifact.md"
        if not selected_codes:
            return path
        return f"{path}?{urlencode([('selected', code) for code in selected_codes], doseq=True)}"

    def _move_selection(self, selected_codes: list[str], code: str, direction: int) -> list[str]:
        result = list(selected_codes)
        if code not in result:
            return result
        index = result.index(code)
        target = index + direction
        if target < 0 or target >= len(result):
            return result
        result[index], result[target] = result[target], result[index]
        return result

    def _latest_release_posture(self) -> tuple[str, str]:
        latest_release = read_json(Path(self.config.runtime.state_root) / RELEASE_ROOT_NAME / LATEST_RELEASE_JSON)
        if latest_release is None:
            return ("not_run", "No release readiness artifact has been recorded in the local runtime yet.")
        verdict = latest_release.get("verdict") or {}
        return (str(verdict.get("status") or "not_run"), str(verdict.get("summary") or "No release readiness summary recorded."))

    def _arena_headline(self, project: ProjectSnapshot) -> str:
        return f"{project.project_name} needs {project.health.tier.replace('_', ' ')} attention now."

    def _arena_risk_statement(self, project: ProjectSnapshot) -> str:
        if project.top_issues:
            return project.top_issues[0].detail
        if project.trust_indicator.status != "high":
            return project.trust_indicator.rationale[0]
        return "No single dominant risk statement was emitted by the current adapters."

    def _arena_why_it_matters(self, project: ProjectSnapshot) -> str:
        if project.top_issues:
            return project.top_issues[0].detail
        if project.latest_notable_changes:
            return project.latest_notable_changes[0].summary
        return project.executive_summary

    def _arena_action_statement(self, project: ProjectSnapshot) -> str:
        if project.health.required_actions:
            action = project.health.required_actions[0]
            return f"{action.owner_hint}: {action.action}"
        return "No immediate corrective action was emitted."

    def _arena_change_statement(self, project: ProjectSnapshot, comparison_trust: ComparisonTrust) -> str:
        if project.comparison_status != "trusted":
            return self._brief_statement(comparison_trust.ranking_detail, max_words=14)
        if project.delta.summary:
            return self._brief_statement(project.delta.summary, max_words=14)
        return "No material change surfaced versus the prior run."

    def _arena_metrics(self, project: ProjectSnapshot) -> list[ArenaMetric]:
        metrics = [
            ArenaMetric(label="Health", value=f"{project.health.health_score:.1f}"),
            ArenaMetric(label="Risk", value=project.health.risk_level),
            ArenaMetric(label="Domain", value=project.domain.title()),
        ]
        if project.schedule and project.schedule.finish_date:
            metrics.append(ArenaMetric(label="Finish", value=project.schedule.finish_date))
        if project.financial and project.financial.metrics.get("margin_percent") is not None:
            metrics.append(ArenaMetric(label="Margin", value=f"{project.financial.metrics['margin_percent']:.1f}%"))
        return metrics[:5]

    def _arena_evidence(self, project: ProjectSnapshot) -> list[str]:
        evidence = [issue.label + ": " + issue.detail for issue in project.top_issues[:3]]
        evidence.extend(change.summary for change in project.latest_notable_changes[:3])
        evidence.extend(project.trust_indicator.rationale[:2])
        return evidence[:6]

    def _comparison_label_for_project(self, project: ProjectSnapshot) -> str:
        if project.comparison_status == "trusted":
            return "Authoritative delta-driven ranking"
        if project.comparison_status == "contained":
            return "Trust-bounded ranking"
        return "Current-run-only ranking"

    def _project_comparison_detail(self, project: ProjectSnapshot, comparison_trust: ComparisonTrust) -> str:
        if project.comparison_status == "trusted":
            run_id = project.comparison_run_id or comparison_trust.comparison_run_id or "prior distinct run"
            return f"Delta-sensitive comparison is authoritative against {run_id}."
        if project.comparison_status == "contained":
            return f"{comparison_trust.baseline_label}. {comparison_trust.ranking_detail}"
        return f"{comparison_trust.baseline_label}. {comparison_trust.ranking_detail}"

    def _arena_scope_summary(self, selected_codes: list[str]) -> str:
        count = len(selected_codes)
        noun = "item" if count == 1 else "items"
        return f"{count} promoted {noun} in the current meeting slate."

    def _arena_selection_summary(self, selected_codes: list[str]) -> str:
        if not selected_codes:
            return "No promoted items are currently selected."
        return "Agenda order: " + ", ".join(selected_codes)

    def _arena_artifact_filename(self, selected_codes: list[str]) -> str:
        suffix = "-".join(selected_codes) if selected_codes else "no-selection"
        return f"arena-executive-handoff-{suffix}.md"

    def _brief_statement(self, text: str, *, max_words: int) -> str:
        cleaned = " ".join(str(text).split()).strip()
        if not cleaned:
            return ""
        first_sentence = cleaned.split(". ", 1)[0].strip()
        words = first_sentence.rstrip(".!?").split()
        if len(words) > max_words:
            clipped = " ".join(words[:max_words]).rstrip(",;:")
            return clipped + "..."
        if first_sentence.endswith(("...", ".", "!", "?")):
            return first_sentence
        return first_sentence + "."

    def _count_phrase(self, count: int) -> str:
        noun = "item" if count == 1 else "items"
        return f"{count} {noun}"


def _merge_identity(left: ProjectIdentity, right: ProjectIdentity) -> ProjectIdentity:
    method_rank = {"manual_override": 3, "raw_match": 2, "fuzzy_match": 1}
    winner = left if method_rank[left.match_method] >= method_rank[right.match_method] else right
    aliases = sorted({*left.aliases, *right.aliases})
    source_keys = sorted({*left.source_keys, *right.source_keys})
    return winner.model_copy(update={"aliases": aliases, "source_keys": source_keys})


def _dedupe_provenance(values: list[SourceArtifactRef]) -> list[SourceArtifactRef]:
    result: list[SourceArtifactRef] = []
    seen: set[tuple[str, str, str]] = set()
    for value in values:
        key = (value.source_system, value.artifact_type, value.path)
        if key not in seen:
            result.append(value)
            seen.add(key)
    return result
