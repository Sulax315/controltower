from __future__ import annotations

from controltower.config import load_config
from controltower.render.markdown import render_portfolio_summary, render_project_dossier, render_project_weekly_brief
from controltower.services.controltower import ControlTowerService


def test_markdown_renderers_emit_frontmatter(sample_config_path):
    config = load_config(sample_config_path)
    service = ControlTowerService(config)
    portfolio = service.build_portfolio()
    project = portfolio.project_rankings[0]

    dossier = render_project_dossier(project, config.obsidian, portfolio.generated_at)
    weekly = render_project_weekly_brief(project, config.obsidian, portfolio.generated_at)
    summary = render_portfolio_summary(portfolio, config.obsidian)

    assert dossier.body.startswith("---\n")
    assert "## Executive Summary" in dossier.body
    assert "project_id: AURORA_HILLS" in weekly.body
    assert "## What Changed This Week" in weekly.body
    assert "## Required Actions" in weekly.body
    assert "## Overall Portfolio Posture" in summary.body
    assert "## Portfolio Risk Ranking" in summary.body
