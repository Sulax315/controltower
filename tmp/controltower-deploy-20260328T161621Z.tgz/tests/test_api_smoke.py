from __future__ import annotations

from fastapi.testclient import TestClient

from controltower.api.app import create_app
from controltower.config import load_config
from controltower.services.controltower import ControlTowerService
from controltower.services.meeting_readiness import verify_meeting_readiness


def test_api_and_pages_render(sample_config_path):
    config = load_config(sample_config_path)
    service = ControlTowerService(config)
    record = service.export_notes(preview_only=False)
    app = create_app(str(sample_config_path))
    client = TestClient(app)

    home = client.get("/")
    assert home.status_code == 200
    assert "Executive operating view" in home.text
    assert 'id="root-scan-posture"' in home.text
    assert 'id="root-section-material-changes"' in home.text
    assert "Projects Ranked By Health / Risk" not in home.text
    assert client.get("/projects").status_code == 200
    arena = client.get("/arena?selected=AURORA_HILLS")
    arena_export = client.get("/arena/export?selected=AURORA_HILLS")
    arena_artifact = client.get("/arena/export/artifact.md?selected=AURORA_HILLS")
    assert client.get("/arena").status_code == 200
    assert client.get("/arena/export").status_code == 200
    assert client.get("/arena/export/artifact.md").status_code == 200
    assert arena.status_code == 200
    assert arena_export.status_code == 200
    assert arena_artifact.status_code == 200
    assert 'id="arena-scan-headline"' in arena.text
    assert "Why It Matters" in arena.text
    assert "Download Authoritative Markdown" in arena.text
    assert "Print / PDF view is presentation-only" in arena_export.text
    assert "## Scope / Timestamp" in arena_artifact.text
    assert "Summary: 1 item. Aurora Hills:" in arena_artifact.text
    assert "## Supporting Project Detail" in arena_artifact.text
    assert "Agenda order: AURORA_HILLS" in arena_artifact.text
    assert "Trust-bounded ranking" in arena_artifact.text
    meeting = verify_meeting_readiness(config, ["AURORA_HILLS"])
    assert meeting["status"] == "pass"
    assert meeting["checks"]["root_collapsible_sections_have_concise_summary_lines"] is True
    assert meeting["checks"]["arena_is_more_presentation_oriented_than_root"] is True
    assert client.get("/runs").status_code == 200
    assert client.get("/diagnostics").status_code == 200
    assert client.get(f"/runs/{record.run_id}").status_code == 200
    assert client.get("/projects/AURORA_HILLS/compare").status_code == 200
    assert client.get("/api/portfolio").status_code == 200
    assert client.get("/api/diagnostics").status_code == 200
    payload = client.get("/api/projects/AURORA_HILLS").json()
    assert payload["canonical_project_id"] == "AURORA_HILLS"
    assert payload["domain"] == "professional"
    portfolio_payload = client.get("/api/portfolio").json()
    assert portfolio_payload["comparison_trust"]["status"] == "contained"
    assert portfolio_payload["comparison_trust"]["ranking_authority"] == "trust_bounded"
    assert portfolio_payload["domain_coverage"][1]["available"] is False
