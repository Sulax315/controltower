---
title: Portfolio Weekly Summary
type: portfolio_weekly_summary
generated_at: '2026-03-28T20:15:48Z'
run_date: '2026-03-28'
project_count: 2
active_project_count: 2
tags:
- controltower
- portfolio-summary
---

# Portfolio Weekly Summary

## Overall Portfolio Posture

Portfolio requires intervention: 1 project(s) carry HIGH risk and average health is 43.1.

## Key Metrics

- Generated at: `2026-03-28T20:15:48Z`
- Active projects: **2**
- Average health score: **43.1**
- Risk distribution: **LOW 0 / MEDIUM 1 / HIGH 1**

## What Changed This Week

- Waverly Dorm: Schedule held flat versus the prior run. Financial posture was effectively unchanged. No material risk movement was detected against the prior run.

- sample data: Schedule held flat versus the prior run. No prior financial baseline was available for comparison. No material risk movement was detected against the prior run.



## Top Risks

- [[Waverly Dorm - Dossier]]



## Required Actions

- Waverly Dorm: Validate and remove 2 schedule cycle(s) before the next publish.

- sample data: Validate and remove 2 schedule cycle(s) before the next publish.



## Portfolio Risk Themes

- Circular schedule logic (2)

- Open-end exposure (2)

- Margin pressure (1)

- Missing financial feed (1)

- Negative float pressure (1)



## Portfolio Risk Ranking

- **Waverly Dorm**: HIGH risk | Critical | score 13.0

- **sample data**: MEDIUM risk | Watch | score 73.3


## Source Provenance

- `schedulelab` | `schedule_dashboard_feed` | `C:\Dev\ScheduleLab\schedule_validator\published\runs\SU_WAVERLY\outputs\dashboard_feed.json`

- `schedulelab` | `schedule_summary` | `C:\Dev\ScheduleLab\schedule_validator\published\runs\SU_WAVERLY\outputs\summary.json`

- `schedulelab` | `schedule_run_manifest` | `C:\Dev\ScheduleLab\schedule_validator\published\runs\SU_WAVERLY\outputs\run_manifest.json`

- `schedulelab` | `schedule_management_actions` | `C:\Dev\ScheduleLab\schedule_validator\published\runs\SU_WAVERLY\outputs\management_actions.json`

- `schedulelab` | `schedule_management_brief` | `C:\Dev\ScheduleLab\schedule_validator\published\runs\SU_WAVERLY\outputs\management_brief.md`

- `profitintel` | `profitintel_validation_db` | `C:\Dev\ProfitIntel\data\runtime\validation_20260327_219128_current\validation.db`

- `profitintel` | `profitintel_workbook` | `C:\Dev\ProfitIntel\data\runtime\validation_20260327_219128_current\raw_reports\219128\219128 Profit Report Update_2026-03-25.xlsx`

- `schedulelab` | `schedule_dashboard_feed` | `C:\Dev\ScheduleLab\schedule_validator\published\runs\SAMPLE_DATA\outputs\dashboard_feed.json`

- `schedulelab` | `schedule_summary` | `C:\Dev\ScheduleLab\schedule_validator\published\runs\SAMPLE_DATA\outputs\summary.json`

- `schedulelab` | `schedule_run_manifest` | `C:\Dev\ScheduleLab\schedule_validator\published\runs\SAMPLE_DATA\outputs\run_manifest.json`

- `schedulelab` | `schedule_management_actions` | `C:\Dev\ScheduleLab\schedule_validator\published\runs\SAMPLE_DATA\outputs\management_actions.json`

- `schedulelab` | `schedule_management_brief` | `C:\Dev\ScheduleLab\schedule_validator\published\runs\SAMPLE_DATA\outputs\management_brief.md`
